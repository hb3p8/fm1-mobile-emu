#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# FiMba-1 host tests: the maths, the platform pieces kept from Felucca / X0X / FoMni, the instrument
# (built without libm, as on the device), and the whole firmware app in the simulator
# (tests/scenarios/*.kal: keys, black-key modes, MIDI, FX, persistence), with screenshots and audio in
# build/scenarios/ and one WAV per tine material in build/host/materials/.
#   tests/run_tests.sh
set -u
cd "$(dirname "$0")/.."
CC="${CC:-cc}"
FAIL=0
OUT=build/host
mkdir -p "$OUT" "$OUT/materials" build/scenarios
run() {
    name="$1"; shift
    if "$@" > "$OUT/$name.log" 2>&1; then
        echo "  ok   $name"
    else
        echo "  FAIL $name (see $OUT/$name.log)"
        tail -15 "$OUT/$name.log" | sed 's/^/       /'
        FAIL=1
    fi
}
run fastmath sh -c "$CC -O2 -ffp-contract=off -Wall -Wextra -Werror -o $OUT/fastmath_test tests/host/fastmath_test.c -lm && $OUT/fastmath_test"
run encoder sh -c "$CC -O2 -w -Ifirmware/hal -o $OUT/encoder_test tests/host/encoder_test.c && $OUT/encoder_test"
run uac sh -c "$CC -O2 -w -Ifirmware/src -Ifirmware/hal -o $OUT/uac_test tests/host/uac_test.c -lm && $OUT/uac_test"
run trs sh -c "$CC -O2 -w -Ifirmware/src -Ifirmware/hal -o $OUT/trs_test tests/host/trs_test.c && $OUT/trs_test"
# no -lm: a libm call that crept into the engine fails to link here, as it would on the device
run kalimba sh -c "$CC -O2 -ffp-contract=off -std=c99 -Wall -Wextra -Wdouble-promotion -Werror -DOM_HOST -Ifirmware/src/dsp \
    -o $OUT/kalimba_test tests/host/kalimba_test.c firmware/src/dsp/kalimba.c && $OUT/kalimba_test $OUT/materials"
run storage sh -c "$CC -O2 -o $OUT/storage_test tests/storage_test.c && $OUT/storage_test"
# the update path, against the firmware package (Felucca's tests; needs ./build.sh)
if [ -f build/fimba.fwsc ]; then
    run ota-entry sh -c "$CC -o $OUT/ota_test tests/ota_test.c && $OUT/ota_test build/fimba.fwsc"
    if [ -z "${AC79_SDK:-}" ]; then
        echo "  skip update-loader (needs AC79_SDK, as the build)"
    else
    run update-loader sh -c "head -c 100000 build/fimba.bin > $OUT/old_app.bin && \
        python3 tools/fm1pkg_make.py $OUT/old_app.bin build/loader/ota.bin $OUT/old.fwsc >/dev/null && \
        $CC -o $OUT/ldr_test tests/ldr_test.c && $OUT/ldr_test $OUT/old.fwsc build/fimba.fwsc"
    fi
    run installer python3 tests/install_test.py
    # the package taken apart and every CRC checked; against FoMni's own package when one is there
    # (build/fomni-ref: see BUILDING.md, "Before installing")
    REF=""
    [ -f build/fomni-ref/build/omni.fwsc ] && REF="--ref build/fomni-ref/build/omni.fwsc"
    run package sh -c "python3 tools/check_fwsc.py build/fimba.fwsc --app build/fimba.bin $REF"
else
    echo "  skip update-path tests (no build/fimba.fwsc: run ./build.sh)"
fi
run host-build sh host/build_host.sh
if command -v emcc >/dev/null 2>&1; then
    run emu sh -c "sh web/emu/build.sh >/dev/null 2>&1 && node tests/host/emu_test.mjs build/emu/kalimba.wasm"
    CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    [ -x "$CHROME" ] || CHROME="$(command -v google-chrome || command -v chromium || true)"
    # the installer as the page ships it, against a simulated FM-1
    run updater node tests/web/updater_test.mjs
    if [ -n "$CHROME" ]; then
        run standalone node tests/host/standalone_test.mjs "$CHROME"
        if [ -f build/fimba.fwsc ]; then       # the installer's buttons, end to end (needs a firmware build)
            run installer-page node tests/web/installer_page_test.mjs "$CHROME"
        fi
    fi
fi
for s in tests/scenarios/*.kal; do
    n=$(basename "$s" .kal)
    mkdir -p "build/scenarios/$n"
    run "scenario-$n" build/host/kalimba_host "$s" "build/scenarios/$n"
done
[ $FAIL -eq 0 ] && echo "all tests passed" || echo "TESTS FAILED"
exit $FAIL
