#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
"""Build the main-loop code for size (build.py): the functions defined in SIZE_FILES get LLVM's
minsize (about -Oz) while everything else (the sound, render and ISR code, the flash and OTA code,
the main loop) keeps -Os. The JieLi clang 4 has no '#pragma clang attribute' and its minsize
attribute is an error on variables, so build.py compiles felucca.c to LLVM IR without the
optimizer, this script adds 'minsize' to those definitions, and the IR is then compiled at -Os
(without the edit, that round trip is byte-identical to compiling felucca.c directly).
The opt-in PERF_HW build uses the separate selective policy documented below.
  size_fns.py IN.ll OUT.ll"""
import os
import re
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
SRC = _ROOT / "firmware" / "src" if (_ROOT / "firmware" / "src").is_dir() else _ROOT / "src"   # either layout
# the UI, the stores, the editor and the console: main loop only, never called by sound code; and (1.1) every
# other file without DSP: USB, MIDI, the sequencer, the drawing, the LCD, OTA, ... Of those, what an interrupt
# reaches (ISR_ROOTS and everything they call or name, from the IR) keeps -Os (isr_reach)
SIZE_FILES = ["ui.c", "favorites.c", "menu_items.c", "icons.c", "ui_graph.c", "ui_draw.c", "ui_menu.c", "ui_input.c",
              "storage.c", "upreset.c", "project.c", "settings_persist.c",
              "editor.c", "editor_preferences.c", "editor_backup.c", "editor_menu.c", "console.c",
              "usb.c", "midi_uart.c", "midi_control.c", "midi_clock.c", "seq.c", "song_chain.c", "chord.c", "motion.c",
              "panel.c", "lcd.c", "gfx.c", "ota.c", "ota_hw.c", "up_fm6.c", "slice_store.c", "params.c", "editor_fm6.c",
              "ui_layer.c", "ui_name.c", "ui_slice.c", "ui_events.c", "main.c", "libc.c", "storage_hw.c", "engines.c", "fm4_convert.c",
              "ui_tools.c", "ui_fm6op.c", "ui_lfo2.c", "ui_help.c", "ui_drumx.c", "midi_learn.c", "editor_drumx.c", "editor_learn.c",
              "editor_palette.c", "editor_lfo2.c", "category.c", "fm6_vbank.c", "drumx_control.c"]
ISR_ROOTS = ("fm1_alnk0_irq", "fm1_timer5_irq")      # hal/fm1_isr.S: the audio ISR, the key / LED scan (+ USB poll)
DEF = re.compile(r"^(?:static|void|int|uint\w*|int\w*|const)\b[^;=(]*?\b([A-Za-z_]\w*)\s*\(", re.M)
IR_DEF = re.compile(r"^(define [^\n]*?@\"?([\w.]+)\"?\([^\n]*\)(?: unnamed_addr| local_unnamed_addr)?)( #\d+[^\n]*\{)$",
                    re.M)


def definitions(text):
    """names of the functions text defines (a signature at column 0 whose ')' is followed by '{')"""
    names = []
    text = re.sub(r"/\*.*?\*/|//[^\n]*", " ", text, flags=re.S)        # comments (none hold code)
    for m in DEF.finditer(text):
        i, depth = m.end() - 1, 0
        while i < len(text):
            depth += {"(": 1, ")": -1}.get(text[i], 0)
            i += 1
            if depth == 0:
                break
        rest = re.sub(r"^(__attribute__\s*\(\(.*?\)\)\s*)+", "", text[i:i + 200].lstrip())
        if rest.startswith("{"):
            names.append(m.group(1))
    return names


def size_names():
    names = set()
    for f in SIZE_FILES:
        names.update(definitions((SRC / f).read_text()))
    # Opt-in performance UI/store code follows the same main-loop-only policy.
    # ISR reachability below still protects pair DSP, macro mixing and sequencing.
    for folder in ("home-perf", "engine-pair-morph"):
        for path in (_ROOT / "experiments" / folder).glob("*.c"):
            if "test" not in path.stem:
                names.update(definitions(path.read_text()))
    return names


IR_BODY = re.compile(r"^define [^\n]*?@\"?([\w.]+)\"?\((.*?)^\}", re.M | re.S)
IR_REF = re.compile(r"@\"?([\w.]+)\"?")


def isr_reach(ir):
    """the functions an interrupt can run: ISR_ROOTS and, transitively, every function their bodies call or
    name (a pointer taken there counts as called), from the unoptimised IR (before inlining: a superset)"""
    body = {m.group(1): m.group(2) for m in IR_BODY.finditer(ir)}
    seen, todo = set(), [r for r in ISR_ROOTS if r in body]
    while todo:
        f = todo.pop()
        if f in seen:
            continue
        seen.add(f)
        todo += [g for g in IR_REF.findall(body[f]) if g in body and g not in seen]
    return seen


def main(src, dst):
    ir = Path(src).read_text()
    isr = isr_reach(ir)
    names, hit = size_names() - isr, set()
    if os.environ.get("FELUCCA_PERF_HW") == "1":
        # Full -Os does not fit. Retain V4's compact policy outside DRONE/VA
        # and the explicit performance-audio helpers. No engine is removed.
        audio = {"hp_begin", "hp_end", "pair_mix_begin", "pair_tone_begin",
                 "pair_motion_weights", "pair_power_gain", "pair_apply_gain"}
        for filename in ("eng_drone.c", "eng_hades.c", "eng_sem.c", "va_blocks.c"):
            audio.update(definitions((SRC / filename).read_text()))
        # Include signatures with attributes before their return type, too.
        audio.update(m.group(2) for m in IR_DEF.finditer(ir)
                     if m.group(2).startswith(("drone_", "hades_", "sem_", "va_")))
        # V9 candidate: retain normal -Os inlining in the common hot FX path.
        audio.update({"track_filter", "tf_wet_block", "tf_sample", "tf_pole", "pf_mix", "mulq16",
                      "track_dist", "ins_drive", "ins_shape", "softclip",
                      "master_out", "dc_block", "lowcut1"})
        if os.environ.get("CARAVEL_DUALCORE_D1")=="1":
            # Cold setup paths need no hot-loop inlining policy.
            audio -= {n for n in audio if n.endswith(("_init", "_reset", "_note_on", "_note_off")) or n in {"drone_cell_seed","drone_motion_values","drone_motion_load"}}
        names = {m.group(2) for m in IR_DEF.finditer(ir)} - audio

    def mark(m):
        if m.group(2) not in names:
            return m.group(0)
        hit.add(m.group(2))
        extra = " noinline" if os.environ.get("CARAVEL_DUALCORE_D1")=="1" and m.group(2) not in isr and (m.group(2) == "sound_name" or m.group(2).startswith(("ui_", "draw_", "gfx_", "menu_", "ed_", "proj_", "settings_", "storage_", "hp_", "up_", "con_", "upf_", "fvb_", "layer_", "lcell", "pat_", "cv_", "text_"))) else ""
        return m.group(1) + " minsize" + extra + m.group(3)
    Path(dst).write_text(IR_DEF.sub(mark, ir))
    print(f"size: {len(hit)} functions explicitly built for size ({len(names) - len(hit)} not in this build; "
          f"{len(hit & isr)} interrupt-reachable control/helpers included)")
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:3]))
