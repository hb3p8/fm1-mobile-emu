# Changelog

What Caravel adds to Felucca and what it fixes in Felucca's own behaviour. Caravel is a fork of Felucca by Leo Kuroshita and
Hügelton Instruments (see [NOTICE](NOTICE)): it grew out of the author's use of **Felucca 1.5**, the first recorded commit builds on
**Felucca 1.5.1**, and the 1.6 and **1.6.1** sources were taken in later. Everything below is on top of Felucca 1.6.1; Felucca's own
release notes are in its wiki. Features that come from other people's work name their authors. Nothing here is tested on a real FM-1
unless it says so; host tests and simulations are not hardware measurements.

## [0.6.0] - 2026-10-27

### Added
- STASIS: fixed-pitch granular capture from the internal reverb send, LIVE/HOLD,
  foreground texture strength and a combined MOTN filter/reflection/damping macro.
- Unified REVERB page, CAPT/STR/MOTN modulation destinations, HOLD-to-LIVE fading
  and STOP release with a natural HALL tail.
- STASIS LAYER page: bounded ADD overdubs and timed BLEND transitions into a held
  texture, with explicit OCT+ start/cancel, silent-input protection and seamless
  incremental commits. Two 0.743-second capture banks share the existing 128-KiB
  audio allocation. Layer mode, amount and time use retired global IDs.
- Compatibility warning before loading projects that require omitted SLICE,
  ROOM or SPRING. CANCEL preserves the current session; TEST converts only the
  working copy. Original slots and incompatible last-session autosaves are protected;
  save an audition as a copy. SLICE parameters stay intact in stored originals.

### Validation scope
- The 0.6.0 target profile contains HALL/STASIS; SLICE, ROOM and SPRING are omitted.
  Ordinary tempo DELAY is suspended while STASIS uses the shared delay buffer.
- Full host, golden audio, MIDI, storage, UI, sanitizer, dual-core and web suites
  passed automated validation. Legacy ROOM/SLICE assertions use their complete host reference
  configuration; exact reduced-profile checks run separately. No golden or CPU
  baseline is automatically rewritten.
- Publication includes illustrated STASIS tutorials, a four-page PDF and three
  original sound examples rendered by the actual native firmware DSP. The report
  checks individual machine-readable results and rejects missing/failed cases.
- FM-1 listening, real-time CPU/stability and physical USB/OTA acceptance remain
  hardware checks, not claims made by host simulation.

## [0.5.0] - 2026-10-25

### Added
- **A performance HOME for each track:** up to 32 rows of four references. Turn a
  parameter on its normal page, hold GLO and tap HOME to add it. SELECT chooses
  the active row; ALGO chooses the track. The active row is large and its neighbour
  stays compact. Both rows retain their K1-K4 order. HOME > EDIT CELLS provides
  source navigation, reordering, removal, target selection and one-step HOME undo.
- **Four macros per track, four routes per macro.** MACRO and MACRO MAP are in the
  ENV page family. Each route offsets a continuous parameter on its own track;
  amount is signed, zero is neutral, and offsets do not overwrite the sound's base.
- **Pair Morph:** one pair of eligible pitched tracks shares note gestures while
  retaining both sound engines. PAIR in the ENV family provides PARTNER, ON/OFF,
  MORPH and optional MOTION. The partner adopts A's voice mode. SPREAD must be off;
  fixed voice reservations and unsupported key-map engines are refused with a
  reason. HOME can hold the Pair controls and shows both preset names and live mix.
- **Performance project storage:** HPM1/10,000-byte WORK and A-D snapshots retain
  sounds, HOME, macros, performance events and Pair state together. Full USB
  backups and the command-line .hpm tool support the extension. Live saves commit
  after STOP. Existing native projects remain importable.
- **Bounded, opt-in USB diagnostics** for audio timing and overload counters.
- **Graphical tutorials:** six illustrated chapters using real firmware frames,
  with HOME setup, Pair, macros, saving, second core and held-note muting.

### Changed
- HOME prioritises active values, preset name, track and Pair state. Automatic
  SOUND/FX/MACRO/PAIR/MIX row labels describe assignments. A sound-change star
  compares the current sound to the saved preset; performance level/pan/mute and
  running modulation phases do not mark the sound as edited.
- New performance backups retain the user-preset slot reference. Older backups
  cannot reconstruct a previously lost name; keep user banks with the performance.
- **Second core remains opt-in, OFF by default, and needs a restart.** The worker
  renders complete engine jobs; track effects and shared buses stay on core 0.
  HOME reports actual 1C/2C status. Render comparisons are equal; no universal
  CPU percentage or guaranteed three-track capacity is promised.
- The fixed **FM-1_999** identity and private preview build path prepared in 0.3.4
  are carried forward. Unversioned builds keep FM-1_900. The loader marker is
  unchanged. 0.3.4 was not published separately.

### Fixed
- **Track Mute also ramps already sounding LATCH voices down** (issue #2). Held
  voices may resume when unmuted. LATCH is preserved, new triggers remain blocked,
  and existing global effect tails decay normally.
- The external-clock delay-time glide from **0.3.3 remains included**. The 0.3.4
  identity branch adds no separate delay-DSP patch.

### Compatibility and validation
- Sound presets are not complete performance projects. Use matching tools for
  complete backups; older firmware cannot restore the HOME/Macro/Pair layer.
- The maintainer reports the D3 hardware test passed. The 0.5.0 firmware sources
  retain that functional code; only the version label/comment changes.
- CPU GUARD and the separate V11 silent-FX experiment are not included.
- Full hosted CI passed for the functional candidate, including the inherited
  regression suite, installer preview and browser emulator build.

## [0.3.3] — 2026-10-20

### Fixed
- **A click in the delay on the external clock.** The delay's TIME follows the tempo, and on an external clock the measured beat is
  re-estimated every quarter note and moves by a few samples; the delay's read position jumped with it, which is a click in the echo
  (host model: a beat step of 66 samples, 0.3 %, made the largest sample step of a held sine 47 times larger; now about 1.5 times).
  Changes of up to 1024 samples now glide (the read goes between two samples, time constant 2^14 samples, a few cents of pitch while
  it moves); a larger change (the TIME knob, a new note value) jumps as before. A steady beat is bit for bit as before. Host-tested
  only (`tests/delay_ext_test.c`); the click was reported on a device with the clock from an Oxi One and the delay on.

## [0.3.2] — 2026-10-20

Host-tested only: the DRONE changes below were chosen from a host prototype and its renders; **the sound has not been heard on a real FM-1**
and the CPU cost there is not measured. No new parameter, no format change.

### Added
- **DRONE cell modes (TOPO 3..5): CHAR is also the wave shape.** From a pure sine at CHAR 0 through a triangle (about CHAR 69) to a soft,
  rounded square (0.65 of the way at CHAR 89, at most 0.8), computed from the cell's phase-modulated angle, with the old soft-cubic
  CHAR blend on top. **Roughness:** a cell's coupling (x0.9..x1.6) and character (x0.8..x1.4) follow how far its pitch is from the anchor
  cell (rough: minor second, major seventh, tritone; pure: unison, octave, fifth). **Breathing:** each cell's loudness also moves on its own
  slow triangle (0.17..0.43 Hz, up to 25 % deep at DRIFT 127, proportional to DRIFT, exactly neutral at DRIFT 0). See
  [docs/engines/drone-cells.md](docs/engines/drone-cells.md). Host tests: `tests/drone_cells_test.c` (one-sample oracle for the new arithmetic,
  roughness table against exact logarithms, whistle band, harmonics against CHAR).

- **The eleven DRONE cell presets come with a slow movement**: two free-running LFOs (0.05 to 0.20 Hz) on two of the preset's values through the matrix, different for each preset (see [docs/engines/drone-cells.md](docs/engines/drone-cells.md)). The other presets and engines are unchanged. Host-tested only; not listened to on a device.

### Changed
- **The cell presets (DRONE 5..15) sound different**, with the same parameter values (their golden renders changed; the five original presets
  and TOPO 0..2 are bit for bit as before). Their long-term spectra are closer together: the closest pair is IRON BELLS / RUST at 4.2 dB
  (was SUB FOG / SWARM at 8.3), so the test `dc_preset_separation` now asks for 4 dB instead of 8, and the brightness check against the legacy RING
  for 0.5 instead of 0.6 (0.54 at COUPLE 127, was 0.75). The cell state grew from 252 to 352 bytes per DRONE part (limit 12 888).
  The cell renderer's static loop cost on the target is about 24 % higher (tests/target_budget.txt, 1471 to 1824).
- **Build:** 13 more UI / editor source files are built for size (`-Oz`, `tools/size_fns.py`): the image is 4 048 B smaller, and the loop costs
  checked in `tests/target_budget.py` do not move. This makes room for the DRONE changes (image 574 220 B of 581 564 B).

### Fixed
- **DRONE cell modes: a steady whistle near 11 kHz (a quarter of the sample rate) with high CHAR and COUPLE** (GLASS CHOIR, STATIC): the
  cells' feedback loop has a one-sample delay and its gain reached x1.5 there. A one-pole low-pass in the feedback path removes it (the
  strongest 100 Hz band at 10.2-11.8 kHz: -58 dB / -50 dB below the whole spectrum, was -18 / -11 dB). Cells are somewhat duller at high COUPLE.
- **LATCH: the keys of latched notes stay lit** after their release (and with ARP, the arp's chord keys); they go dark when the latch ends. Host-tested only.

## [0.3.1] — 2026-10-20

Includes everything of 0.3.0 and 0.2.0 (below), which were prepared but never published: this is the first release after 0.1.0.

### Changed
- **AMBER is the default colour theme.** A device without saved settings starts in AMBER (it was GREY); the ship mark and the web pages
  use the same amber. A palette you chose and saved stays as it is: MENU > COLOR still lists all of them. Host-tested only
  (`tests/settings_test.c`); not seen on a real FM-1.
- **New look for the web pages** (installer, editor, browser emulator and the site's start page): the dark amber theme of the firmware's AMBER palette (a warm paper theme when the browser asks for a light one), the pixel sailing ship of the device's header as logo and favicon, and pages built from boxes with a title tag on their border. The start page is now a small page with a box per tool instead of a redirect to the installer. Only layout and styling changed: every existing text, notice, licence link and function and the installer's protocol are as before (new are only a one-line tagline and the box titles); nothing new is loaded from other servers. Checked in a browser at phone and desktop width, light and dark; not tested with a real FM-1 or a real USB install.

## [0.3.0] — 2026-10-19 (prepared, never published: its changes are part of 0.3.1)

Includes everything of 0.2.0 (below), which was prepared but never published.

### Added
- **FILTER for every track**: one bipolar knob, **FILT**, the fourth card of the INSERT 2 group (FX family, INSERT, the lower group): to the left a **low-pass**
  (LP, down to 120 Hz), to the right a **high-pass** (HP, up to 3.8 kHz), **OFF** in the middle. It is the last stage of the track's chain (voices, DIST,
  INSERT, SLICER, FILTER, then LEVEL, PAN and the sends), so the sends to the delay, reverb and chorus take the filtered sound, and every engine has it,
  those without a filter of their own too (FM6, GRAIN, PHYS, WHEEL, SLICE, DRUM). 12 dB per octave, no resonance, so it cannot ring; the cutoff glides
  (the whole range in about 48 ms) and the filter fades in and out in 2.9 ms. With SPREAD the left, right and side signals are filtered alike. OFF (the
  default) runs nothing and the track is bit for bit as before. DRUM-X's per-lane image and lane sends are added after the strip and are not filtered (as they pass
  DIST, the INSERT and the SLICER by). FILT can be recorded as automation or a lock (a filter sweep), learned to a CC (MIDI LEARN), and is part of
  the track's FX: a factory preset load sets it OFF unless **FX HOLD** is on; a user preset stores it. It is **not** a modulation destination in
  this version. See [docs/track-filter.md](docs/track-filter.md). Host tests only (`tests/trackfilter_test.c`: responses of 18 settings against the analytic ones,
  smoothing, all settings on loud signals against a 64-bit shadow of the arithmetic, the chain order, stored data); no measurement on a real FM-1, and its CPU
  cost there is not measured (the host's instructions: about 3 % of an 8-voice part).
- The web editor has a **FILTER** page in its FX group and shows the card text (OFF, or the share with LP / HP).
- CDC status: `clk_gap_min_ms` / `clk_gap_max_ms` / `clk_gap_odd` (the spread of the gaps between Clock stamps, cleared when printed) and
  `uart_events` / `uart_noevent` (UART takes with and without a receive event pending) to capture real numbers from a device.

### Changed
- **The INSERT view**: the upper group is TYPE, MIX, **FX HOLD** and the type's curve (one card wide, 50 px); the lower group is INS A, INS B, INS C and **FILT**.
  FX HOLD moved from the fourth card of INSERT 2 to the third card of INSERT (KNOB 3); it is the same device setting as MENU > VOICES > FX HOLD. The
  footer of the lower group reads INSERT A-C FILT. FX HOLD now keeps the filter along with the sends and the INSERT.
- **Storage (a new track parameter): 114 instead of 113 parameters.** FILT is parameter 105, just before the engine values, which moved from 105..112 to 106..113
  (P_COUNT 114, P_E0 106; the editor protocol's `INFO` says so). Everything saved by 0.1.0 or 0.2.0 (projects with their automation, user presets, backups, the
  editor's library files) loads with the filter OFF and everything else unchanged. **The other way round: 0.2.0 and 0.1.0 cannot open a project saved by
  0.3.0** (their slot shows EMPTY; the saved copy stays until something is saved over it); a user preset saved by 0.3.0 loads there without the filter; MIDI
  LEARN entries for FILT are ignored there. This is why the version is 0.3.0, not 0.2.1. The project format (FUN10, 3840 bytes) did not change, but it has one
  spare byte left, and 114 parameters are the most its automation ids allow: a further common track parameter would need a new format. The web editor
  served with 0.3.0 knows the new layout; the one of 0.2.0 does not.

### Fixed
- **SLICER parting from the sequencer on the external clock.** The sequencer follows the clock pulses, the SLICER's step clock ran on
  the audio's own time with a step length from the whole BPM shown, so the two moved apart (host model: 3..8 ms a minute, more when the
  tempo is turned). The step length now comes from the measured beat, and every block the SLICER's phase in its step is moved towards
  the phase the sequencer's clock units give (at most 4 samples a block). Host model, 120 s at 63..174 BPM with CCs and with the tempo
  swept +-25 % every 6 s: no drift (< 0.05 ms a minute at a steady tempo). Internal clock: unchanged. Host-tested only
  (`tests/slicer_test.c`, `tests/midi_clock_cc_test.c`).
- **TRS MIDI clock with a controller on the same line: the BPM no longer jumps and the sequence holds its time better.** The tempo was
  measured over six Clock pulses with 1 ms stamps, so a steady 120..174 BPM read ±1..4 BPM, and every CC ahead of a Clock on the wire (up to
  3 bytes, ~1 ms) added to that; each such reading also re-scaled every track's phase and the gate/FX times. The tempo is now taken over the
  last 24 pulses (a tempo step or gap starts the window again), the BPM display moves only when the measured tempo is a whole BPM off, and the
  clock's in-pulse interpolation runs at the measured tempo instead of the last single (1 ms rounded) pulse gap. Host model (20 s, 60..174 BPM,
  CC every 5..12 ms or bursts): displayed BPM 172..176 → 174, sequencer position jitter up to 4.8 ms → 2.8 ms peak to peak. See
  [external clock](docs/sequencer/external-clock.md). Host-tested only; the cause of a swing larger than this on the device is not established
  (the new CDC counters below measure it).


## [0.2.0] — 2026-10-19 (prepared, never published: its changes are part of 0.3.0)

### Added
- **LATCH** (CHORD page, KNOB 3): OFF, NEW or STACK per track keeps the notes of the keys, the chord keys and MIDI IN sounding after release.
  NEW replaces the latched set with the next press, STACK adds notes and ends them with the same key or chord again; with ARP the arp keeps the list.
  Ends with LATCH OFF, ARP on, STOP, a panic, or **OCT- + OCT+ together** (which also still resets the octave). See [docs/latch.md](docs/latch.md).
  It uses the unused track parameter 8 (the retired FX slot), so no project, preset or protocol format changes. In the web editor the
  inert FX slot is gone from ENV DEST and LATCH is on the CHORD page. Host tests only (`tests/latch_test.c`).
- **FX HOLD** (the fourth card of INSERT A / B / C, and MENU > VOICES, last row; OFF by default): with ON, loading a factory preset (PRESETS, an engine
  change, MIDI program change, the editor) keeps the track's four sends (DST CHO DLY REV) and its INSERT instead of setting the preset's sends and
  switching the INSERT OFF. The rest of the sound is still the preset's; the SLICER, ARP, SCL and the mix stay as they always did. A user preset
  still loads its own sends and INSERT. SOUND INIT, project INIT and power-on always start from the preset's sends; CLEAN INIT clears them. The
  global DLY, REVERB and CHORUS are never touched by a sound load. See
  [Loading sounds and the track's FX](docs/menus-and-pages.md#loading-sounds-and-the-tracks-fx). Editor menu id 41 (OFF / ON, VOICES tab); a device
  setting stored in the settings byte that already holds 2ND CORE and EXT START (bit 2), so user presets, projects and settings formats are unchanged.
- **The caravel**: Caravel's mark, a 28 x 17 pixel ship (72 bytes of flash, no RAM), is a faint watermark in the header, between the track and the
  transport, and sails over the power-on screen for about 0.6 s (MENU > ANIM OFF keeps the plain 0.4 s splash).
- **A tag in every group's header** says whether it is for **ALL** tracks (the global effects) or for the selected track (T1 to T4).
- **Pictures below a group**: SLICER shows its step pattern and what it does to a tone, INSERT the curve of its type, SCL its scale on the keys and
  CHORD the chord on each scale note (DIA3, DIA7) and the last chord's notes.
- **docs/installing.md**: installing a specific release (web installer and command line), checking it and going back to the official firmware; the
  command-line installer prints a risk notice before its question.

### Changed
- **The FX family** is four views: FX SENDS | DELAY, REVERB | CHORUS, INSERT TYPE / MIX | INSERT A / B / C and SLICER (before: FX | INSERT, INSERT 2,
  SLICER, DLY, REVERB, CHORUS).
- **The LFO family** is three views: LFO | LFO SYNC, LFO2 | LFO2 SYNC and LFO DEST | MOD. The MOD group shows SLOT, SRC, DST and AMT of the slot being
  edited, and four small pips in its header show which of the four slots are in use.
- **ANALOG's FILTER** shares a view with MORE (after VOICE); on SEM the MORE page is not shown (SEM MODE has SPREAD).
- **Every page with a card row frames it** in the theme colour (as the active group of a two-group page is), so the cards KNOB 1-4 edit look the same
  everywhere (not in the LINE style, the layers and the name entry).
- **The splash** shows the name, the version, the maker and the licence; the origin from Felucca stays in ABOUT and the credits. A development build says
  `-dev` after its version (a release build does not).
- **MOD's DST** (in the LFO DEST | MOD view) shows the engine's own parameter names (DRONE: SPREAD, DETUNE, ...) instead of E1 .. E8.
- Menu id 41 is FX HOLD.

### Fixed
- **SEQ held + F5 (CLEAR STEP) with step entry armed** no longer leaves an F in the step: when the key reaches the device a few milliseconds before the SEQ button, step entry had already written it. The layer now takes that write back, silences the key and clears the step as intended.

## [0.1.0] — 2026-10-19 (first version under the name Caravel)

### Changed
- **Release/source delivery:** complete source with pinned engine files, matching notices, build identity and checksums;
  the installer and emulator use the selected release's source. Git-less source archives can rebuild the versioned binary.
- **New name and version line**: Caravel 0.1.0, based on Felucca 1.6.1. Display names, USB manufacturer and product strings, installer,
  editor and emulator texts, package names (`caravel-X.Y.fwsc`), ABOUT / CREDITS, and the legal texts ([NOTICE](NOTICE),
  [LICENSING.md](LICENSING.md), [CREDITS.md](CREDITS.md)). Data formats and package markers are unchanged, and the editor, installer
  and `tools/fm1_install.py` accept devices named Caravel and Felucca.
- **The FX family order** is FX, INSERT, INSERT 2, SLICER, DLY, REVERB, CHORUS (Felucca: FX, SLICER, INSERT, INSERT 2, ...).
- **SELECT starts on PAGE** on a device without saved settings (saved settings, including BPM, are kept).
- **EDIT on the STEP page opens the EDIT pages** like on every other page; it no longer clears the cursor step.
- **DOUBLE** (Felucca 1.6) also copies locks, automation and fine FX edges, up to 64 steps.

### Added: usability
- **Two parameter groups on one screen** for LFO, LFO2, ENV, ARP, VOICE, EDIT 1 / 2 (engines without a sound picture), LANES and
  FX / INSERT. The active group is framed and marked EDIT K1-4, SELECT steps through the groups, and the footer shows a numbered view
  ("LFO TOP 1/4"; a pair counts as one view). A small pictogram shows the selected LFO wave and the ENV shape.
- **In the settings menu, SELECT walks the rows** and continues into the next tab (with SELECT on PAGE).
- **CLEAR STEP: hold SEQ and press F5** clears the cursor step and its locks and moves on; one undo (SAVE held).
- **MORE page** (EDIT family): SPREAD, MORPH and PHS FB on one page; slots the engine lacks are empty. It replaces the single-parameter
  pages MORPH, FEEDBACK and VOICE 3.
- **Per-track voice reservations** (HOME held, ALGORITHM to VOICES): AUTO or FIXED, 1..5 voices per track, at most eight; also in the
  editor.

### Added: live performance and sequencer
- **Live part switching A–D** at track 1's loop boundary, **saving parts while playing** (RAM ONLY until STOP commits them to flash),
  and **LIVE LOAD FULL** (MENU > AUDIO), which also restores sounds, engines, track FX, FM6 patches, DRUM-X kits and the global FX.
- **STEP REC while the pattern plays** (SEQ held + REC, an input step independent of the playhead).
- **FX specials recorded** (all fourteen white-key specials with their timing), edited (start and duration of each FX event) and deleted
  (one performance, one undo); a **global FX track** (FX TRACK T1–T4, saved with the project); **project INIT** without a reboot.
- **External MIDI clock**: GLO + PLAY and GLO + F4 resync or start on the next bar or pulse, and EXT START (PULSE or BAR) for plain PLAY.

### Added: sound and modulation
- **LFO2**: an independent second LFO per track (speed, wave, phase, fade, sync, trigger, polarity), routable through MOD as LFO2,
  S&H2 or SLEW2. The former "LFO 2" settings page is named LFO SYNC.
- **Engines**: **SEM** (after the Oberheim SEM: two oscillators, LP / notch / HP blend, band-pass, voice drift, eight presets),
  **HADES** (after the Dreadbox Hades: dry bass voice with two phase-locked suboctaves, three-pole low-pass, drive and BODY, eight
  presets), **DRONE** (four coupled generators; experimental) with **cell modes** (TOPO CELLPAIR / CELLCHN / CELLRING, slow neighbour
  inhibition) and cell presets. SEM, HADES and DRONE are own designs, not emulations.
- **DRUM-X**: eight lanes with A/B patches and MORPH, modes, drive, layer, feedback, sends, global X-MOD and IMAGE, per-lane MIDI Learn.
  Adapted from **JIANT** by juanjiant-bit; the idea follows Sonic Charge's Microtonic.
- **MORPH** on ANALOG, PHASE, LOFI and DRUM-X, and **PHASE feedback**: adapted from **JIANT** by juanjiant-bit. Both support step
  locks, automation, MIDI Learn and MOD destinations.
- **LOFI BYTE and FLOAT waves** (32 formulas each, presets BYTEBEAT and FLOAT FM): adapted from **JIANT** by juanjiant-bit; the
  bytebeat and floatbeat formulas acknowledge Tejeez, xpansive and viznut.
- **Web editor**: support for LFO2, DRONE cells, DRUM-X, voice reservations and LIVE LOAD.

### Fixed in Felucca's behaviour
- **External MIDI clock drift**: sequencers, ARPs and the metronome keep fractional timing continuously, the clock counts fixed musical
  units, and external ARPs keep step overshoot. A simulated 20-minute run at 120 BPM drifted by about 109 ms in Felucca's 1/16 sequencer;
  the new regression allows 2 ms. Host simulation only.
- **TRS MIDI clock under CC load**: clock, start, continue and stop are timestamped during audio rendering, so heavy controller traffic
  no longer delays them.

### Storage and compatibility
- Settings grew append-only (PER5 to PER7: DRUM-X assignments, voice reservations, favorites of the new engines). Older settings import;
  older firmware cannot read PER6 or PER7 records, so back up before going back to Felucca.
- Sounds and projects with LFO2, DRONE cells, DRUM-X, MORPH or PHS FB need Caravel; existing Felucca projects and sounds load unchanged.
- Menu ids 32 and up are Caravel's (FX TRACK, LIVE LOAD, 2ND CORE, EXT START, voice reservations); 0..31 follow Felucca 1.6.

