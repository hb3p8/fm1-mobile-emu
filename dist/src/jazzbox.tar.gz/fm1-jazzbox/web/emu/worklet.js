// SPDX-License-Identifier: GPL-3.0-only
// MIN-1 in an AudioWorklet: min.wasm is the whole FM-1 app (web/emu/min_web.c). Each render
// quantum asks it for 128 frames, which runs the device's clock forward; between quanta the page's
// input goes in and, about 30 times a second, the screen, the lights, the output's peak and any saved
// objects go out. While the page records, the output also goes out as 16-bit stereo, half a second
// at a time.

const clock = globalThis.performance ? () => globalThis.performance.now() : () => Date.now();
const REC_CHUNK = 22050;                              // frames a recorded chunk

class Min extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ex = null;
    this.input = null;
    this.sentBlits = -1;
    this.sentWrites = -1;
    this.lastFrame = 0;
    this.busy = 0;
    this.frames = 0;
    this.peak = 0;
    this.rec = null;                                  // recording: the chunk being filled, interleaved
    this.recAt = 0;
    this.previewEvents=[];this.previewFrame=0;
    this.port.onmessage = (e) => this.onMessage(e.data);
  }

  async onMessage(m) {
    if (m.type === "load") {
      const now = () => BigInt(Math.round(currentTime * 1e9));
      const wasi = {
        clock_time_get: (id, prec, out) => {
          new DataView(this.mem.buffer).setBigUint64(out, now(), true);
          return 0;
        },
        fd_write: (fd, iov, n, out) => { new DataView(this.mem.buffer).setUint32(out, 0, true); return 0; },
        proc_exit: () => {},
      };
      const stub = new Proxy(wasi, { get: (t, k) => (k in t ? t[k] : () => 0) });
      const env = new Proxy({}, { get: () => () => 0 });
      const { instance } = await WebAssembly.instantiate(m.wasm, { wasi_snapshot_preview1: stub, env });
      this.ex = instance.exports;
      this.mem = this.ex.memory;
      if (this.ex._initialize) this.ex._initialize();
      const max = this.ex.web_store_max();
      for (const [obj, bytes] of Object.entries(m.store || {})) {
        const b = new Uint8Array(bytes).subarray(0, max);
        new Uint8Array(this.mem.buffer, this.ex.web_store(+obj), b.length).set(b);
        this.ex.web_store_set_len(+obj, b.length);
      }
      this.sentWrites = this.ex.web_store_writes();
      this.ex.web_master(m.master ?? 2800);
      this.ex.web_boot();
      if(m.preview)this.ex.web_preview_mode();
      this.port.postMessage({ type: "ready" });
    } else if (!this.ex) {
      return;
    } else if (m.type === "preview") {
      this.ex.web_preview_mode();this.previewFrame=0;this.previewEvents=(m.events||[]).slice().sort((a,b)=>a.frame-b.frame||a.velocity-b.velocity);
    } else if (m.type === "param") {
      this.ex.web_param(m.param,m.value);
    } else if (m.type === "preset") {
      this.ex.web_preset(m.value);
    } else if (m.type === "transport") {
      this.ex.web_transport();
    } else if (m.type === "buttons") {
      this.ex.web_buttons(m.mask >>> 0);
    } else if (m.type === "keys") {
      this.ex.web_keys(m.mask >>> 0);
    } else if (m.type === "enc") {
      this.ex.web_enc(m.role, m.n | 0);
    } else if (m.type === "master") {
      this.ex.web_master(m.value | 0);
    } else if (m.type === "rec") {
      if (m.on && !this.rec) {
        this.rec = new Int16Array(REC_CHUNK * 2);
        this.recAt = 0;
      } else if (!m.on && this.rec) {
        this.sendRec(true);
      }
    }
  }

  sendRec(end) {                                      // the chunk so far to the page; the last one names the take
    const pcm = this.rec.slice(0, this.recAt), msg = { type: "rec", pcm, end };
    if (end) {
      const p = this.ex.web_title(), b = new Uint8Array(this.mem.buffer, p, 40);
      let s = "";
      for (let i = 0; i < b.length && b[i]; i++) s += String.fromCharCode(b[i]);
      msg.title = s;
      this.rec = null;
    } else {
      this.recAt = 0;
    }
    this.port.postMessage(msg, [pcm.buffer]);
  }

  publish() {
    const ex = this.ex;
    const blits = ex.web_blits();
    const msg = { type: "frame", buttons: ex.web_lit_buttons() >>> 0, keys: ex.web_lit_keys() >>> 0, peak: this.peak,
                  song: ex.web_song_state() };      // 0 none, 1 recording, 2 playing
    const cstr=(p)=>{const b=new Uint8Array(this.mem.buffer,p,64);let s="";for(let i=0;i<b.length&&b[i];i++)s+=String.fromCharCode(b[i]);return s};
    msg.jazz={scale:ex.web_scale(),anchors:ex.web_anchors(),playing:ex.web_playing(),position:ex.web_position(),scaleName:cstr(ex.web_scale_name()),params:Array.from(new Int16Array(this.mem.buffer,ex.web_params(),ex.web_params_count())),chords:[]};
    msg.jazz.score={active:ex.web_score_active(),bar:ex.web_score_bar(),chorus:ex.web_score_chorus(),walking:ex.web_score_walking()};
    msg.jazz.forms={active:ex.web_forms_active(),count:ex.web_form_count(),bass:ex.web_form_bass(),piano:ex.web_form_piano(),bassName:cstr(ex.web_form_bass_name()),pianoName:cstr(ex.web_form_piano_name())};
    for(let i=0;i<ex.web_cycle_count();i++)msg.jazz.chords.push(cstr(ex.web_chord_at(i)));
    this.peak = 0;
    if (this.frames >= 44100) {                       // the share of real time spent running the device
      msg.load = Math.round(100 * this.busy / (this.frames / 44.1));
      this.busy = this.frames = 0;
    }
    const transfer = [];
    if (blits !== this.sentBlits) {
      this.sentBlits = blits;
      msg.fb = new Uint16Array(this.mem.buffer, ex.web_fb(), 240 * 240).slice();
      transfer.push(msg.fb.buffer);
    }
    const writes = ex.web_store_writes();
    if (writes !== this.sentWrites) {
      this.sentWrites = writes;
      msg.store = {};
      for (let o = 0; o < ex.web_nobj(); o++) {
        const n = ex.web_store_len(o);
        if (n >= 0) msg.store[o] = new Uint8Array(this.mem.buffer, ex.web_store(o), n).slice();
      }
    }
    this.port.postMessage(msg, transfer);
  }

  process(inputs, outputs) {
    if (!this.ex) return true;
    const out = outputs[0];
    const n = out[0].length;
    const t0 = clock();
    while(this.previewEvents.length && this.previewEvents[0].frame<=this.previewFrame){const e=this.previewEvents.shift();this.ex.web_audition(e.part,e.note,e.velocity);}
    this.previewFrame+=n;
    this.ex.web_render(n);
    this.busy += clock() - t0;
    this.frames += n;
    const l = new Float32Array(this.mem.buffer, this.ex.web_out_l(), n), r = new Float32Array(this.mem.buffer, this.ex.web_out_r(), n);
    out[0].set(l);
    if (out[1]) out[1].set(r);
    for (let i = 0; i < n; i++) this.peak = Math.max(this.peak, Math.abs(l[i]), Math.abs(r[i]));
    if (this.rec) {
      for (let i = 0; i < n; i++) {
        this.rec[this.recAt++] = Math.max(-32768, Math.min(32767, Math.round(l[i] * 32767)));
        this.rec[this.recAt++] = Math.max(-32768, Math.min(32767, Math.round(r[i] * 32767)));
        if (this.recAt === this.rec.length) this.sendRec(false);
      }
    }
    if (currentTime - this.lastFrame >= 1 / 30) {
      this.lastFrame = currentTime;
      this.publish();
    }
    return true;
  }
}

registerProcessor("min", Min);
