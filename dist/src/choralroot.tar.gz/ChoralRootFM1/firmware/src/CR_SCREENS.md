# ChoralRoot FM-1 screens (`cr_screen.h`, `cr_draw.c`, `cr_gfx.c`)

The renderer of the 24 approved mock-ups (`design/choralroot-fm1-screens.png`, drawn by the designer's
`renderScreen` in `../ChoralRootFM1Designer/index.html` from `design/choralroot-fm1-mockups.json`) on Felucca's
graphics layer (`gfx.c`). `tests/run_cr_draw.sh` renders every state on the host and lints the layout.

```
#include "gfx.c"
#include "cr_gfx.c"      /* shapes + scalable text on gfx.c's canvas; includes build/gen/cr_fonts.h */
#include "cr_draw.c"     /* includes cr_screen.h */
...
cr_screen_t s;  cr_screen_clear(&s);  /* fill it from the engine / UI state */
cr_draw(&s, ms_since_the_change);     /* every frame; cheap when nothing changed */
```

## The view-model (`cr_screen.h`)

`cr_screen_t` mirrors the designer's `screen` object, flattened: `kind` (`CR_K_STRIPES CHORD PICKER METER KEYBOARD
ARP GEEK TEXT BIG SCOPE EDIT8 STACK KNOBROW LOOPMENU`), the top line (`header`, `icon` none/play/rec/loop, `mid`/`mid_col`, `right`/`right_col`,
`batt`), `footer` (one line; empty = none, the panel then runs to row 240), the ring (`ring_on`, `ring` Q8,
`ring_rec`, `ring_col`), the corner dial (`dial_on`, `dial` Q8, `dial_pulse`, `dial_mode` CR_DIAL_*, `dial_dot`), `message`/`message_col`, and the panel fields of every kind (fixed char arrays; the chord
name as `cr_name_t {root, quality, sup, col_root, col_quality, col_sup}`; up to 8 notes `{t, col, mark}`; a picker
window of 8 items with `n_items`, `item0`, `sel`; 4 params columns; 27 keys as a `lit` bitmask + `lit_col[]` +
`key_label[]`). Colours are `cr_col_t`: ChoralRoot's seven + black (fixed RGB565 in `cr_draw.c`, not per palette:
white 246,243,234, red 224,58,47, blue 43,80,200, yellow 242,183,5, orange 240,122,26, green 47,179,122, grey
110,110,118, black 0,0,0) and the palette tokens (BG SURF TEXT THEME ACCENT MID DIM LINE REC); `CR_COL_NONE` takes
the designer's default for that field. Fractions are Q8 (`CR_ONE` = 256).

The producer must start from `cr_screen_clear()` each frame: the cache hashes the struct's bytes.
`tests/gen_cr_screens.py` is the reference translation from the designer's JSON (its defaults made explicit; a token
the designer resolves in its MOD palette becomes the named colour: THEME red, ACCENT yellow, TEXT white).

## Animations (pure functions of `(s, anim_ms)`)

`s->anim` says which are running; `anim_ms` is the time since the change that started them (the tween clock).
`cr_anim_busy(s, ms)` is 1 while frames are still to come. Past their durations they draw exactly the settled screen
(tested).

| flag | fields | motion |
| --- | --- | --- |
| `CR_A_SQUEEZE` | `from`, `name`, `squeeze` | 120 ms: `from` thins to an 8 % column (ease-in, 60 ms), `name` stretches out of it (ease-out, 60 ms); no `from`: stretch only. Multiplies the fit-to-224 px factor and the forced `squeeze` (state 24's frame) |
| `CR_A_SLIDE` | `slide` (sel came from sel − slide) | 160 ms ease-out: the old item leaves and the new one enters inside the item's box (a reel); vertical or horizontal |
| `CR_A_FILL` | `pct_from` → `pct` | one stripe every 30 ms; more than 14 stripes to light (a pool's meter: up to 32): all of them in the 420 ms of 14 |
| `CR_A_STRIPES` | `phase`, `period_ms` | the bands' phase advances a cycle per `period_ms` (40 px per cycle, as the designer's `phase`) |
| `CR_A_SWEEP` | — | the bands are swept off to the right, 240 ms each, 40 ms apart (the first chord) |
| `CR_A_LIFT` | `rt_held`, `rt_drop` (route) | 120 ms ease-out: the held block rises 10 px (Parallel 5), or the one let go lands; `CR_A_SLIDE` on a route: every block eases from its `rt_from` place to its `rt_order` one in 160 ms |

No flag, the producer's motion (`cr_ui.c` `cu_animate`, `cr_anim.c` `cr_spring`): a meter's number and a `big`
panel's value **spring in** through `size` (meter 92 → 104 px, big ¾ → its size, 240 ms) whenever the value changes:
the count-in's 4 3 2 1, undo's layers left, PANIC. `size` is in the hashed bytes, so the cache redraws each step.
A `big` panel with `ring_on` lifts its value, sub and label 22 px clear of the ring's band.

## Strips and the cache

The screen is drawn as **six strips of 240 × 40** (gfx.c's canvas holds 240 × 124, `CV_MAX`); each strip runs the
whole composition with `cv_oy = −top`, so layout code is in screen coordinates and everything is clipped by the
canvas (text and glyphs outside the strip's rows are skipped). Order as the designer: header, panel, footer, ring,
message.

- **Signature**: FNV of the struct + the animation frame (`cr_frame_t`: the squeeze, slide offset, stripes filled,
  shift, sweep) + the palette generation (`ux.gen`). Unchanged and not forced: `cr_draw` returns at once (nothing
  drawn, nothing blitted) — a settled screen costs one hash per frame.
- **Changed**: every strip is drawn, its pixels hashed, and only strips whose hash changed are blitted (the SPI
  transfer is the expensive part). A header change blits 1 strip; the ring appearing blits 6.
- **Only the ring's fraction moved** (the signature without `ring` unchanged: a playing loop on a still screen):
  only the strips holding band pixels between the old and the new tip are drawn (`cr_ring_strips`: the band's rows
  over those angles, widened by two pixels; usually one strip, two where a strip edge is crossed; the loop's restart
  clears the whole ring: all six). The other strips are neither drawn nor blitted.
- **Only the corner dial moved** (`dial`, `dial_pulse`, `dial_mode`, `dial_dot` hashed apart like `ring`): strip 0
  alone is drawn (the REC dot's blink included).
- **Only the loop menu's moving parts changed** (`lm_lane`, `lm_pos`, `lm_erase0/1` hashed apart; other kinds hash
  them with the rest): the timeline's strips (rows sy−6 .. sy+43: a playhead, a new mark, the Replace span), the
  step grid's (the marks), or the step cursor's old and new rows' strips alone (the cursor moving or blinking:
  usually one strip).
- `cr_draw_invalidate()`: the next draw blits all six (after Felucca's UI drew, a palette change, power-up).
- `cr_draw_black()`: the whole panel black in one `lcd_fill`, the cache dropped with it (the screen off after 10
  minutes without input, `cr_ui.c cr_ui_draw`: black pixels with the backlight on, since the backlight's pin also
  keeps the key matrix alive, `hal/fm1_lcd_hw.h`); the next draw, the wake's, blits all six whole.

**The ring** (`cr_ring_draw`): its pixels never move, only its colour and fraction change, so the coverage of the
band is computed once, at build time, with `cr_arc`'s own per-pixel code (`cr_arc_px`) into a `const` table in flash
(since 0.16: `cr_ring_table.h`, generated and checked byte for byte by `tests/cr_draw_test.c`'s `cr_ring_build`;
`CR_RING_GEN=1 sh tests/run_cr_draw.sh` rewrites it; until 0.15 it was built at boot into the POOL): per row up to two runs of pixels, a byte a pixel (the solid band's and the dotted
circle's sample counts as one index of the 153 pairs d <= s), 4 232 pixels, 6.1 KB. A frame blends its rows' runs
from the table; the progress is decided per run from the angles of its end pixels (the angle is monotonic along a
row): a run well inside the sweep takes the band's coverage, one well outside nothing, and only pixels within
64 / 65536 turn of the start or the tip (more than any sample's angle differs from its pixel's) take `cr_arc_px`'s
16 samples. The pixels are exactly `cr_arc`'s (`tests/cr_draw_test.c` compares both at 258 fractions over a pattern,
and the partial draws with full draws). Host instructions a UI frame with a loop playing on the chord screen: 1.0 M
(0.58 M with no ring at all); before, 12.8 M with the arp (`tools/emu/perf.sh` c: now 2.4 M, 1.2 M with no ring).

**The corner dial** (`cr_dial`, from `cr_header`): the ring is drawn only where the loop is the whole screen (the
count-in and the undo screen, set by `cr_ui.c`; calibration uses it as its progress); every other loop state is the
dial (2026-10-09; before, the capture states drew the ring under every screen): the producer sets `dial_on` on every
screen with a top line but the Options pages (the sound editor has none) while `lstate` is PLAYING or `lcap` is
ARMED / REC / OD_ARMED / OD (`cu_dial_state`), with `dial_mode` CR_DIAL_PLAY (playing), ARMED (REC armed with no loop,
or an overdub armed over the playing loop), REC (the first take) or OD (an overdub) and `dial_dot` (the REC dot lit
this frame: the REC LED's twin, lit armed, blinking in its 250 ms phase recording or overdubbing). The dial is Orchid's
ring shrunk into the top line: centre (229, 12), r 8, 3 px — the track as 10 dots of T_LINE, red for CR_DIAL_REC
(`cr_disc`, about 2 on 3 off; no dashed `cr_arc`, whose per-sample angles cost more), the progress `cr_arc` red
clockwise from 12 o'clock (`dial`: the loop's cycle, or the first take's: its N bars with a loop length set, the bar's
position in Free), 5 px wide for `dial_pulse` (the downbeat's ~100 ms, skipped with Motion Off), and the REC dot, a
red `cr_disc` r 3 at the centre, for `dial_dot`. The header's `right` text moves 22 px left while it shows; nothing
else moves (the panel keeps its height, pickers their marks and footers). Rows 2..22, so strip 0 only: a moving
dial redraws one strip (`perf.sh` c, a 1-bar loop at 200 BPM under the arp: 2.70 ms a UI frame on the device
scale, 2.95 ms with the ring it replaced). Fixtures: `tests/gen_cr_screens.py` reads the designer's `loop` dial (`rec`
armed / rec / od, `dot`); states 63–67 are design/choralroot-fm1-loop-mockups.json's 7, 9a–9c, 10 (`LOOP_PICK`), and
the main sheet's 10 / 11 (drawn with the ring there) carry the dial (`MAIN_DIAL`); `tests/cr_draw_test.c` checks the
looks (`loop_dial_armed / rec / od`) and lints texts on the dial.

## Type: faces, sizes, flash

Bold type (the mock-ups' 600/700/800) is **Inter Tight 700**, regular (500) is Felucca's own faces:

| face | where | flash |
| --- | --- | --- |
| `AF_CRX` 104 px / 700, 1 phase, Huffman, sparse: `space # + - . 0-9 ? A-G I J M N P T W Z b d i m s u` (37 glyphs) | the chord root (104 px), quality (60 px), the meters' numbers (104 px), PANIC (64 px), the arp's root (44 px) | **14 272 B** |
| `AF_CRB` 40 px / 700, 1 phase, Huffman, ASCII + Felucca's extras (· … etc.) | everything else bold, 7–40 px: superscripts, pickers (40 / 36 px), values (20 px), notes lines (16 / 13 px), titles (34 / 26 / 15 px), header (15 px), labels (11 px), key labels (7 px) | **16 099 B** |
| `AF_M` 15 px / 500, `AF_S` 12 px / 400 (existing) | regular text 13–15 px (M, native), 12 px (S, native), < 12 px (S resampled) | 0 |

Total new flash for fonts: **30 371 B** (generated as `build/gen/cr_fonts.h` by `tools/gen_aa_font.py --preset
choralroot`, run by `tools/build.py generate()`). Figures are proportional (as the mock-ups' "13", "120").

**Why option (a)**, resampling two big faces, not (b) a 52 px face pixel-doubled: the 52 px chord-charset face is
6 510 B, so (b) saves ~7.8 KB, but a 2× pixel-doubled glyph has 2 × 2 px steps and a two-pixel-wide anti-aliasing
ramp on every edge — at ~220 ppi the chord name (the one big thing on the screen) visibly loses the mock-up's crisp
104 px outline. With (a) the root is drawn 1:1 from a 104 px raster (unhinted 16× supersampled area coverage, as
Felucca's faces), and the same resampler that draws every other size does the squeeze. A 104 px nibble-packed face
would be > 64 KB; Huffman (the gfx.c coder) makes it 14 KB.

**The resampler** (`cr_gfx.c` `cr_glyph`): the glyph is decoded into an 8 KB buffer (the largest, CRX 'W', is
104 × 76), then each destination pixel takes the area-weighted sum of the source pixels under it (separable box
filter, overlaps in 1/256 px, scales in Q12, up to 16 source pixels per axis), quantised to the 16 coverage levels and
blended with gfx.c's coverage curve into whatever the canvas holds (so type on a block, a key or a stripe needs no
"under" colour). At 1:1 it is a straight copy at whole pixels. A squeeze is a horizontal scale only.

RAM (`.pool`): glyph buffer 8 192 B, column weights 9 216 B, two Huffman tables 1 032 B — 18.4 KB; the ring's
table (`cr_draw.c` `cr_ring`) 6.1 KB and the cache (`cr_dc`) 44 B.

## Shapes (`cr_gfx.c`)

All anti-aliased with 4 × 4 samples, blended into the canvas: `cr_frect` (fractional edges), `cr_disc`, `cr_arc`
(radius, width, start, sweep, round caps, dashes along the arc: the ring's dotted circle is width 5, dash 2 of 6 at
R 113), `cr_poly` (polyline, round joins and caps, dashes; joins blend once; per row only the segments whose box reaches
it, per pixel only those reaching its columns, a pixel none reaches skipped: a curve's cost is its own pixels, not its
box's), `cr_quad` (quadratic, as a 16-segment polyline: the arp's dotted hop, the filter glyph). `cr_arc_px` takes a
pixel whose centre is well inside or outside an undashed arc's sweep (by more than a sample's angle can differ) as
all in / out without the samples' angles. Both are pixel for pixel the exhaustive tests (INTEGRATION Performance). Integer `cr_sin`/`cr_cos` (quarter table), `cr_atan2`, `cr_isqrt`.
`cr_clip` limits these draws to a rectangle (the picker's slide window). gfx.c is unchanged.

## The MOD palette

Added to `tools/gen_ui_palettes.py` as the ninth palette: bg 0,0,0 (10,10,12 through 0.25.1: the backlight showed it
as a dark grey; 3y185), surf 28,28,32, text 246,243,234, accent 242,183,5 as asked; **theme 248,96,48 instead of
224,58,47**: the red fails the generator's WCAG checks ink/sel (3.44 < 4.5: background-coloured text on a selection
row) and theme/surf (4.05 < 4.5), and 248,96,48 is the nearest colour that passes all of them. ChoralRoot's screens
never use the THEME token for red — they use the named red, exact — so the mock-ups are unaffected; THEME serves
Felucca's own pages when MOD is picked. `tests/theme_test.c` and `tests/ui_test.c` now expect nine palettes (MOD
last; saved palette ids unchanged).

## What differs from the mock-ups, and why

- **Weights**: one bold weight (700) for the mock-ups' 600/700/800: the quality, superscripts, header and labels
  (600) are a little heavier; the stripes' title (800) a little lighter. Regular 13–14 px text (picker labels, the
  voicing line, the arp line) uses Felucca's M at 15 px (crisper than resampling M); 10–11 px text (geek status
  lines, the params foot) is S resampled.
- **Hairlines are crisp**: the battery outline, the bars glyph's ticks, and the arp's line
  are whole-pixel lines, where the canvas mock-up draws 1 px strokes on half pixels (blurred over two rows).
- **Rounded corners**: keys (r 1.5) and the battery (r 2) are square-cornered; the arp block, bar glyph and message
  box use gfx.c's `cv_rrect`.
- **The stripes' phase** is the designer's (a 40 px shift of 360 px bands): with skew 0 the bands span the screen at
  every phase, so the slide only shows with `skew` or the sweep (as in the designer).
- **The picker's change** is a slide (a reel inside the item's box), not a split-flap flip.
- The chord squeeze is the designer's horizontal scale, applied to the glyph rasters (no hinting at any width).
- **`CR_K_SCOPE`** (device-only, no mock-up yet): `wave[240]` (int8, ±127 = the panel's half height less 6 px), one
  sample a column. Drawn as a 3 px line, a column at a time: the span the polyline covers within a pixel either side
  (the neighbours' samples) ± 1.5 px as one fractional rectangle (`cr_frect`), only the columns crossing the strip's
  rows; a 1 px grey centre line. `cr_poly` is not used (48 points, every segment tested per sample: far too slow
  for 240 points). The samples are in the hashed struct: a still trace costs one hash, a moving one redraws and
  blits only the strips whose pixels changed. States 25-29 of `tests/gen_cr_screens.py` (`DEVICE_STATES`, not in the
  designer's JSON): the scope sounding and silent, three calibration steps (`CR_K_BIG` 40 px, the ring as progress).
- **`CR_K_EDIT8`, `CR_K_STACK`: the sound editor** (`cr_edit.c` fills them; FORMAT.md "Sound editor panels",
  design/choralroot-fm1-sound-editor-mockups.json; states 30-38 of `tests/gen_cr_screens.py` are that file's states
  1 3 4 6 8 9 11 15 16, the FILTER state mapped onto the device's column order CUT RES FTYPE FENV / KTRK - SPREAD
  DRIVE and the MIX ones given the battery; 39-42 device-only: the mixer, the OSC modes (MORPH / NOISE / TRI glyphs)
  and the FILTER morphing at FTYPE 16). Full screen (`header` 0): the title line (`title` in `title_col`, `page` right), then edit8:
  an optional wide band (QUAD's `CR_W_ALGO`, `CR_W_ADE2` and the filter's base-width window: below; `wide` `CR_W_ENV`: `wv` a h d s r + the lit segment, the AHDSR as one 3 px polyline, its
  steep runs cut into pieces <= 26 px tall so cr_poly's boxes stay small, the lit segment 4 px in the hot cell's
  colour, A H D S R under it; `CR_W_FILTER`: `wv` cut res ftype (0..127) drive, the 2nd-order response of
  the LP / BP / HP mix crossfaded at the FTYPE position (0 LP, 32 BP, 64 HP, 96 NOTCH = LP + HP, back to LP;
  the type word its name, `cr_ftype_name`) sampled at 7 quarter-octave offsets from the cutoff in 32-bit log2 arithmetic, the edges extrapolated, clamped to the band
  with the crossings: <= 12 segments, over a dashed 0 dB line) over two rows of four `cell`s (each `cr_cell_t` carries its label, value, `CR_CF_*` flags, glyph, pct, pct2, wave: 32 bytes); stack: `head` column headings at y 36 over
  `n_rows` rows sharing 41..239 with `rlabel`s (N >= 7: text only). The `active` row in the knob colours (blue
  orange white green) with 2 px bars, the others DIM; `hot_r` (row + 1) / `hot_c`: the value on a block of its
  colour. Glyphs (`CR_G_KNOB BAR WAVE SAW SQUARE STEPS DOTS`, a bipolar BAR centre-zero) are the designer's
  drawGlyph scaled by h / 64; `CR_G_MORPH` (pct = the VA's morph position) two cycles of the crossfaded wave,
  <= 23 segments; `CR_G_NOISE` (pct thirds: WHITE BROWN VINYL) jitter / a wandering line / spikes on a faint line.
  `batt` (not 255): the header's battery at the title line's right end (the MIX screens). No motion (docs/EDITOR.md §10): `hot_r` / `hot_c` and `hot_col` (the block's colour while
  mapping: the modulation source's), a cell's mark (`CR_CF_MARK(colour)` in its flags: a 4 px square at its top
  right). A value too wide loses its space first ("790ms"), then 2 px of size at a time (to 9 px), then ellipsises.
  The cache hashes the editor's parts apart (each row's cells, `wv`, the hot cell, the title line) and composes only
  their strips (`cr_ed_strips`); a cutoff detent: <= 4 M host instructions, measured by tools/emu/test_cr.sh
  (`cr_editor_lag.txt`, `EMU_UI_LOG=0`). The old params page (`CR_K_PARAMS`) is retired.
- **`CR_K_LOOPMENU`: the looper's PLAY menu** (FORMAT.md "The looper's PLAY menu", docs/LOOPER-MODES.md; the approved
  sheet design/choralroot-fm1-looper-screens.png, all 12 states). Under the ordinary top line ("Loop 3" red, the right
  text, the corner dial), in rows: the **slot strip** 28–54 (ten cells over x 6–234, bottom row 50, 3 px apart:
  `lm_used` bit k filled grey with the number in the background colour, an empty one a 1.5 px grey outline with a dim
  number; `lm_slot` red (filled, or a 2 px outline when empty), 5 px taller, its number 13 px; `lm_jump` (target + 1):
  the target drawn selected and a 2 px hop arrow under the cells from `lm_slot` to it); the **record mode** 56–92 as a
  horizontal picker (`items` / `sel` / `col` / the slide, the picker's own pieces: 28 px bold squeezed to 150, the
  neighbours 13 px dim at x 6 / 234, the marks at row 86); the **middle** 92 .. the knob row (`lm_mid`):
  `CR_LM_TEXT` = `title` big (up to 40 px bold, 0.6 of the height, squeezed to 224) in `title_col` (NONE red), `sub`
  12 px grey under it (`mid` is the top line's, so the big text is `title`); `CR_LM_TIMELINE` = the 200 × 40 strip at
  x 20: `lm_bars` bar boxes (surface, a 1 px grey outline) with `lm_beats` ticks (0: 4) at the top and bottom, the
  lanes' marks (`lm_lane[li]` bit c = column c of 64 over the bars shown, 3 px, a lane each over `lm_nlane`; lane li
  `30 × (nlane − 1 − li)` % toward the background (≤ 62 %), the take's lane `lm_newlane` − 1 full red), Replace's span
  (`lm_erase0/1`, Q8 bars: a band 70 % toward the background, a 1.5 px red edge; the older lanes' marks in it grey
  under a red ×), the playhead (`lm_pos`, Q8 bars from the left: a 2 px red line past the strip, a triangle on top);
  `lm_free`: a bar is 50 px, the last one only up to the playhead, no marks past it; `sub` (the elapsed "0:07") 13 px
  grey under it; `CR_LM_STEPS` = the step grid: `lm_bars` rows (≤ 4) of 7 px, 2 apart, `lm_beats` steps a bar (the
  Quantize grid, 0: 16) over 200 px (2 px apart, 2 more between fours), `lm_lane[0]` bit s filled red, the cursor
  `lm_pos` a 2 px red outline in a 1 px background ring, not drawn while `CR_LM_CUR_OFF` is set (its blink: the
  producer's clock; cr_draw has none), `sub` (the step's chord) 15 px bold at the left under it and `value` 12 px grey
  at the right. The **knob row** is knobrow's (`cr_kr_cells`, shared: `cell[0][0..3]`, `hot_r` / `hot_c`), 72 px
  (168–240), or 64 (162–226) over `foot` (11 px grey, centred, baseline 237); a `CR_CF_BIG` cell (Keys) draws its
  value 20 px where the glyph and the value would be. Differences from the mock-ups: the used cells' numbers are the
  background colour as the designer draws them; the empty step's name "–" is "-" in the fixtures.
- **`CR_K_ROUTE`: the FX layer's Routing page** (GitHub issue 21, second design; `cr_p_route`, after FIZZ's MidiFX
  rail, FMToneSeq core/ui/ui_mfx.c; `cr_ui.c` fills it on that page: "THE ROUTING PAGE"). No knob row: the black
  keys and KNOB 1 are the gesture, the footer says so. `label` 12 px bold mid at the top left (`fx · on · chain`),
  `title` ("Routing") 15 px bold green at the right. Wires 2 px FX green with arrowheads, `in` / `out` 12 px bold
  green. A block (`rt_order[k]`: 0 Chorus, 1 Delay, 2 Reverb, 3 Filter, `cr_fx.c XFE_*`) is a rounded box filled
  with its colour (Chorus blue with white ink, Delay orange, Reverb yellow, Filter white with black ink); the Filter
  Off (`rt_filter_on` 0): hollow, a 2 px rim; FX off (`rt_fx_on` 0): every box hollow and every wire grey. `rt_mode`
  1, Chain: the four boxes in a row, 48 × 64, 10 px apart (rows 86–150, the wire through their middles at 118), each
  its place 1–4 at 22 px over its name at 13 (squeezed to the box). 0, Parallel: the three effects stacked (92 × 32,
  x 30, rows 62–174, in `rt_order`'s order), the wire fanning into them from `in` and out into a sum disc with a +,
  then the Filter (52 × 44) and `out`; with the Filter first (`rt_order[0]` 3) it is `in`, the Filter at x 14, then
  the fan, stack and sum 62 px to the right, and `out` (a move between the two slides it all). `rt_held` (block + 1): lifted (`CR_A_LIFT`) over a grey shadow bar at its
  place, ringed white (the Filter green), white arrowheads in the gaps on the sides it can still move to (Chain; Parallel: the Filter only, toward its other place); a
  move slides every block from `rt_from` to `rt_order` (`CR_A_SLIDE`, its texts flagged sliding for the lint);
  `rt_drop` lands. **Cache**: nothing hashed apart, a change composes the six strips (the tiles still blit only what
  changed). Draw test states: Chain, Chain with Delay held mid-move, Parallel, Parallel with the Filter first,
  FX off.
- **`CR_K_KNOBROW`: a layer screen** (FORMAT.md `knobrow`; design/choralroot-fm1-fx-mockups.json, the user-approved
  sheet design/choralroot-fm1-fx-screens.png; `cr_ui.c` fills it for every layer: `cu_fx_cells`, `cu_perf_cells`, `cu_bass_cells`, `cu_key_cells`,
  `cu_loop_cells`, METRO's Click inline, the hot cell `cu_hot_row`; design/choralroot-fm1-layers-mockups.json states
  1, 3, 6, 7 for KEY, LOOP and METRO). `kr_band` 1 (KEY): the band is `cr_keyboard`'s strip (224 px, <= 56 px tall,
  centred under `label`; `lit` / `lit_col` / `key_label` as `CR_K_KEYBOARD`) instead of the picker. `CR_CF_DIM`: the
  cell all in the grey (LOOP's Sync while playing: it cannot change), never hot. The panel's lowest 72 px are one
  row of four knob cells (`cell[0][0..3]`; y 126–198 with a footer, 168–240 without), the rest a horizontal picker
  band drawn by the picker's own pieces (`cr_pick_item` with its slide, `cr_pick_sides`, `cr_pick_marks`): the item
  34 px bold in `col` squeezed to 170 px, its neighbours 13 px dim, the marks under it, `label` 11 px dim top left,
  `value` 13 px bold under the marks. A cell is edit8's active cell made taller: the label 10 px (+11), a 48 × 36 glyph
  box (+15), the value 13 px bold (+66), the 2 px knob-colour bar (+70); with `CR_CF_PCT` and no glyph the bar glyph;
  not `CR_CF_ON`: a dim dash. `hot_r` 1 / `hot_c`: the value on a block of its colour (`hot_col`). The band slides
  (`CR_A_SLIDE`) as a picker's; the row has no motion. **Cache**: the cells and the hot cell are hashed apart as the
  editor's (`cr_ed_strips`, `cr_ed_row_strips` row 0 = the row's strips): a knob turn or the hot block coming or going
  composes strips 3–4 only (with a footer), host ~1.0 M instructions a frame while KNOB 1–4 turn every 30 ms
  (`tools/emu/perf.sh` h; a turn's frame <= 3.0 M, ~11.5 ms on the device); a new effect redraws all six.
- **The pictograms** (`CR_G_ROOM MOON ECHOES LFO CLIP MIX GATE RANGE ARROW SHIFT`, FORMAT.md "cell glyphs"; SPRING
  went with the spring reverb in 0.18; the FX layer's seven of 0.18, `CR_G_TAIL PRE CUT WIDTH SPREAD SYNC PING`, are
  the firmware's own in the same manner (docs/FX.md, cr_screen.h: no designer picture yet);
  `cr_cell_t.pct2` their second value, Q8 of 255): drawn at true size in the glyph box (2 px strokes 2 px inside it,
  not scaled by h / 64 as the params glyphs): room the box (`cr_srect`, fixed) and its far wall growing 22 → 70 % of it with the value, with four corner
  lines (`cr_poly`); moon a lit part (the right half less / plus an ellipse, `cr_moon_fill`: 4 corner samples a
  pixel, 16 where they disagree) inside a 2 px rim (`cr_arc`); echoes 3 px bars decaying by 0.2 + 0.75 pct2, spaced
  by pct, on a 1 px baseline; lfo 1–5 cycles (<= 44 segments), depth by pct2; clip one cycle at gain 1–10, dashed clip
  lines past 0.1; mix an outlined square behind one filled to pct; gate, range, arrow, shift as
  FORMAT.md; tail a struck edge and its curve (each twelfth keeps 0.56 .. all of the last); pre a bar, a gap of pct, a
  wedge; cut a response rising to a corner 25 .. 80 % along; width two bars leaving a dashed centre; spread two rows
  of echoes, the lower one's spacing 1 .. 1/2 of the upper one's (pct2); sync a clock face or two beamed notes; ping two
  walls and four repeats, on both or alternating. tests/cr_draw_test.c checks each one's ink stays in its box and
  changes with pct.
- **QUAD's primitives** (docs/QUAD.md; design/choralroot-fm1-quad-mockups.json, the user-approved sheet
  design/choralroot-fm1-quad-screens.png; the designer's drawWide `algo` / `ade2` / the filter's `bw`, drawPicto `harm`
  `detune` `lfowave`, cellRow's `big`, `ratio`, `span`, the bipolar knob). States 68–76 of `tests/gen_cr_screens.py`
  are that file's states 1–8 and 10 (ENV 3's three cells) (`QUAD_PICK`); `tests/cr_draw_test.c` renders all eight
  algorithms besides (`algo_1` .. `algo_8`, linted).
  - `CR_W_ALGO`: `wv` = algo (0: 1..8), fdbk (1: 0..255), mix (2: 0..255, 128 = X and Y alike). "ALGO" 10 px MID and
    the number 24 px at the left; the diagram is the **Digitone manual's** (Appendix A.3's figure; `CR_ALGOS`, the
    designer's `ALGOS` the same table: per algorithm up to four modulation arrows, the feedback operator, the X / Y
    carriers and the one each label sits under, the **direct** carriers, the carriers whose line leaves their box's
    right side, 3 or 4 rows, each box's row and column). `cr_algo_geom` places them: rows at y 13 / 37 / 61 (four rows:
    11 / 30 / 49 / 68, algorithm 4's stack), 32 px columns, a side line 15 px right of its box's centre, the diagram
    centred on x 137. The 1.5 px MID arrows box edge to box edge with a filled head (4.5 × 5 px, shorter in a short gap:
    `cr_tri`); each carrier's 1.5 px line to its label (the output mix favours in TEXT, the other DIM, both TEXT at
    128): **dotted for a direct carrier** (full level, unaffected by its operator envelope; `cr_poly` dashes 1.5 of
    3.5 px), **solid for an enveloped one**; the label's own carrier straight down (or from its side, then down) to the
    label's top, a second carrier down to the label's middle and across to its side (algorithms 3, 7, 8); the 14 px
    boxes (BG filled, 1.5 px outline, the letter 9 px); the feedback loop the manual's square bracket over its box's top
    left (up 3 px, left past the edge, down, a head back in), 1..3 px with fdbk (clamped to the band's top). The eight:
    1 A(fb)>C, B2>B1>C, X C, Y B1 · 2 A>C, B2(fb)>B1, X C, Y B1 · 3 A(fb)>C, B2, B1, X C + B2, Y B1 · 4 B2(fb)>B1>A>C,
    X C, Y B1 (side) · 5 B1(fb)>A, B2>A, A>C, X C, Y A (side) · 6 A(fb)>C, B1, B2>C, B1, X C, Y B1 · 7 A(fb)>C, B2>B1,
    X C + A, Y B1 + B2 (A, B1, B2 enveloped) · 8 A>C, B1(fb), X C + B2, Y B1 (B2, B1 enveloped); C always direct. Bounded:
    <= 4 arrows, 4 lines, 4 boxes, one loop.
  - `CR_W_ADE2`: `wv` = A's attack decay end level (0..3), B's (4..7) (0..255), the lit segment (8: 1..8 = A's attack
    decay end level, B's; 0 none). A in x 8..112, B in 128..232: each a 3 px TEXT polyline (rise to its level over 40 %
    of its room at attack 1, fall to its end over 40 % at decay 1, held; steep runs cut <= 26 px as the env band), a
    4 px level bar at its right (a LINE track filled to the level: the lit colour when a segment of that half is lit,
    else MID), its letter 10 px top left; the lit attack / decay / hold 4 px in the knob colour of (seg - 1) % 4 with
    dots at its ends (a lit level: the bar and letter only); a 1 px LINE divider at x 119.5.
  - `CR_W_FILTER`'s type for FM TONE: `wv` 7 = 0 the VA's (the position's name), 1 OFF (a flat line at the pass
    level, "OFF"), 2 a 12 dB slope (the name + "12": "LP12" "HP12"), 3 24 dB ("LP24": the response's dB doubled, two
    12 dB stages); the editor sets it from the TYPE column's name (cr_edit.c `ce_band_plan`).
  - `CR_W_FILTER`'s base-width window: `wv` 4 = shown (0 none: a cleared struct draws no window), 5 = base, 6 = width
    (Q8 of 255 of the band; the window base .. base + width, clipped at 255). The designer's lit region is the orange at
    12 % alpha; with no alpha here it is that composite as a **solid dim fill** (`ux_mix(T_BG, orange, 12)`, a dark
    brown, recomputed per palette) under the dashed 0 dB line and the curve — at 240 px a solid fill reads as the
    mock-up does, where a sparse dot pattern shimmered against the dashed lines. Its edges dashed 1.5 px (3 on 3 off)
    orange, `B` / `W` 9 px under them (pushed apart when closer than 12 px).
  - Glyphs: `CR_G_HARM` (pct: one cycle of sin + harmonics 2..7 at 1/k, the odd ones by 2 pct − 1, all by 1 − 2 pct,
    normalised: 40 segments), `CR_G_DETUNE` (pct: 16 segments, the joints jittered by 0.45 H pct from the designer's
    sin(i 78.233 + 1.7) table, every third segment dropped past 0.3, every other past 0.7), `CR_G_LFOWAVE` (`cr_cell_t.wave`
    = `CR_LW_TRI SINE SQUARE SAW RAMP EXP RANDOM`, pct = the start phase: one cycle, two in a span-2 cell, from pct of a
    cycle on; the points are the wave's breakpoints, both sides of each jump, and for sine / exp 16 samples a cycle:
    <= 37; a 1.5 px tick at the left at the start value), `CR_G_RATIO` (not a picture: the value "0.50/1.00" as a
    fraction, both numbers 13 px bold over / under a 1.5 px divider w − 14 wide, centred in the glyph-and-value space; a
    value without '/' draws as a big cell). Harm, detune, lfowave are 2 px strokes at true size, as the pictograms.
  - Cell flags (`flags` is 16 bits now; the mark's colour stays in bits 4..7): `CR_CF_BIG` (the value 7 px larger,
    20 px under a band / 24 px without, centred where glyph and value would be, no glyph, no bar; too wide: 2 px smaller
    at a time to 7 px, never ellipsised), `CR_CF_SPAN2` (edit8 and stack: the cell takes two columns from a column
    0..2, its label fits 116 px, its glyph box doubles, its bar spans both columns in its first column's colour; **the
    cells after it in the row shift a column right**, so cell index != column: `hot_c` is the cell's index, as the
    designer's), `CR_CF_BIPOLAR` (= `CR_CF_BIP`; on a `CR_G_KNOB`: the arc from 12 o'clock to the value, a 1.6 px mark
    over 12 o'clock). `cr_cell_t` is 32 bytes (label 14 for "Wave · Phase", value 12 for "0.50/1.00" and the KEY layer's "Split Bass", flags 16 bits,
    the `wave` byte): + 7 bytes a cell, + 224 bytes a `cr_screen_t` (three in the firmware: `cu_scr` in the POOL, two
    statics).
  - Cache: the bands are hashed with the editor's `wv` as the others (a new algorithm composes strips 0–3 only, the
    partial draw equal to a full one: tested). `tests/cr_draw_test.c` checks the four boxes of every algorithm where
    `cr_algo_geom` puts them, the eight diagrams differing, no boxes / loops / side lines / labels overlapping or off
    the band, a direct line dotted and an enveloped one solid (algorithm 7), the loop thickening with fdbk, ade2's two curves and bars filled to their levels, the
    window's edges and fill (none when off), the fraction, the three glyphs' ink and change with pct, lfowave's seven
    waves, phase and two cycles, a big cell's missing bar and larger value, a span cell over two columns with the next
    cells shifted, the bipolar knob's arc flipping across 0.5. `gen_cr_screens.py` refuses a row whose spans pass the
    fourth column. Not done: span on the knob row (`CR_K_KNOBROW` draws cell[0][k] at column k), the single-envelope
    `ade` band.
- Not implemented (not on the device): the designer kinds `tiles list scope dial roundel splash loop notes`, `big`
  with `pct` (the inverted fill), knob cards, keycap footers, `bubbleStyle: "disc"`, the chord panel's `key`/`trans`.

## Test (`tests/run_cr_draw.sh`)

Builds `tests/cr_draw_test.c` (gfx.c + cr_gfx.c + cr_draw.c on a host framebuffer, as tests/ui_test.c), renders every
state settled (anim cleared, `anim_ms` 0) and mid-animation (80 ms), writes `build/cr_screens/<nn>_<slug>[_mid].png`,
`build/cr_screens/sheet.png` (the designer's sheet layout, 2× nearest) and `build/cr_screens/compare.png` (mock-up |
device | mid-animation per state). Lint (gfx.c `GFX_HOOK_TEXT`, boxes in screen rows, de-duplicated across strips):
no text off the screen, no two texts overlapping, no text on the ring's band. Checks: glyphs fit the buffer, the CRX
charset, the cache (0 / 1 / 6 strips), animations pure and settling. States 45–53 are design/choralroot-fm1-fx-mockups.json's 2 3 4 5 5b (knob rows), 6 7 (the
glyph studies, edit8) and 10 11 (the perform and bass layers); states 54–57 the layers sheet's 1 3 (KEY, the keyboard band), 6 (LOOP, no
ring), 7 (METRO); states 58–62 the preset sheet's 1 2 3 5 6; states 63–71 QUAD's 1–8, 10 (compare.png cuts them from
design/choralroot-fm1-quad-screens.png); states 77–88 the looper sheet's 1–12 (`CR_K_LOOPMENU`, cut from
design/choralroot-fm1-looper-screens.png); state 16 is the main sheet's fx layer, a knob row. The loop menu's checks: the
selected slot red and taller (an empty one an outline), the playhead's column and its move composing the timeline's
strips only, a struck mark in Replace's span, the step cursor's blink composing one strip (partial = full draws). The pictograms and the knob row's hot
block and strips are checked too. Report: `build/cr_screens/report.txt`.
