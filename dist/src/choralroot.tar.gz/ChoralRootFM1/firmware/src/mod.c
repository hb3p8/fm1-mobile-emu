/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Modulation matrix: per track four slots, each SRC -> DST by AMT (-64..63), added to the fixed
 * routings (ENV DEST, LFO DEST). Runs in the audio ISR (fx.c mix_part, voice.c track_render).
 *
 * Sources, Q15:
 *   LFO   the track LFO with its FADE (as LFO DEST), bipolar
 *   ENV   the amp envelope of the voice (after the engine's own amp curve, as ENV DEST), 0..1
 *   VEL   the note-on velocity (before UNISON's level scaling), 0..1
 *   KEY   the note relative to C4, bipolar: +-64 semitones = +-1 (an octave = 0.19)
 *   RAND  a new random value per note-on (its own generator: the shared rng is not touched), bipolar
 *   MODW  MIDI CC1, AT channel aftertouch, EXPR CC11 of the track's channel (seq.c), 0..1; until a
 *         controller arrives (and after CC121 RESET ALL CONTROLLERS) MODW and AT are 0, EXPR 1
 * Destinations:
 *   per voice (vmod_t, like the fixed routings):
 *     PITCH  AMT 63 at a full source = +-11.8 semitones (as LFO DEST PIT)
 *     CUT    m->cutoff, SHP m->shape: AMT 63 = +-63 steps (as ENV DEST); the sums are clamped to what
 *            the fixed routings can reach, so the engines see no new range
 *     AMP    a gain <= 1: AMT > 0 the source opens it (AMT 64: silent at 0, full at 1), AMT < 0 closes it
 *            (bipolar sources as 0..1, as LFO DEST AMP); several AMP slots multiply
 *   per track, once per block: PAN, DIST CHO DLY REV (the sends), RATE (LFO rate), VIB (LFO DEST PIT, the
 *     vibrato depth), E1..E8 (the engine's parameters P_E0..P_E7, named by the engine): AMT 64 at a full
 *     source = the parameter's whole range; the sum is clamped to its range
 * A per-voice source on a per-block destination takes the latest note-on's value (VEL, KEY, RAND), ENV the
 * envelope of the latest note-on's voice (one block late, 0 when it has ended).
 *
 * Per-block destinations are modulated in place: mod_begin writes the modulated values into t->p for the
 * part's block (its render and its mix in fx.c mix_part) and mod_end puts the stored values back. Both run
 * in the audio ISR, so nothing outside it ever sees a modulated value (the UI, the editor, projects and
 * presets read and write t->p from the main loop, which the ISR preempts; TIMER5 only fills the MIDI rings),
 * and the engines read t->p as before. An engine reads its parameters in note_on (events_block) unmodulated.
 * Nothing active (every slot with SRC, DST or AMT at 0): no work, and the sound is bit-identical. */
enum { MS_OFF, MS_LFO, MS_ENV, MS_VEL, MS_KEY, MS_RAND, MS_MODW, MS_AT, MS_EXPR, MS_N };
enum { MD_OFF, MD_PITCH, MD_CUT, MD_SHP, MD_AMP, MD_PAN, MD_DIST, MD_CHO, MD_DLY, MD_REV, MD_RATE, MD_VIB, MD_E1,
       MD_N = MD_E1 + 8 };
_Static_assert(NELEM(N_MSRC) == MS_N && NELEM(N_MDST) == MD_N, "N_MSRC / N_MDST == MS_* / MD_*");
_Static_assert(P_M2SRC == P_M1SRC + 3 && P_M4AMT == P_M1SRC + 11 && P_M4AMT + 1 == P_FM1_ATK, "matrix slots: 3 ids each");
#define NMSLOT 4u
#define MS_VOICE(s) ((s) >= MS_ENV && (s) <= MS_RAND)             /* a value per voice */

/* Options > Key Touch (ChoralRoot, docs/VELOCITY.md; the UI writes these, the ISR reads them): with it Fixed the
 * voices play as before (the linear velocity of the engines without their own envelope, the patch's law in FM6, VA,
 * FM TONE, nothing in CZ-1); Dynamic (and Velocity + Aftertouch) puts one velocity law on every engine's level, after
 * the engine, MONK-1's Touch: Velocity: level = (1 - s) + s x 1.6 x (vel / 127)^2, clamped to 1, s = Velocity Sens
 * (Low 1/4, Mid 1/2, High 1): a medium press (~100) keeps its level, a hard one is full, a light one is quiet.
 * Velocity + Aftertouch also routes the part's aftertouch (t->at: the keys' pressure or MIDI's) to the cutoff by
 * Aftertouch Sens (AMT 24 / 40 / 63) unless the sound's matrix routes AT itself. MIDI notes get the same law. */
enum { CR_TOUCH_FIXED, CR_TOUCH_VEL, CR_TOUCH_VEL_AT };
static volatile uint8_t cr_touch_mode, cr_touch_vsens, cr_touch_atsens;   /* sens: 0 Mid, 1 Low, 2 High */
static int32_t cr_touch_gain(uint32_t vel)        /* Q15 */
{
    static const uint16_t S[3] = {16384, 8192, 32767};
    int32_t x = (int32_t)(vel > 127u ? 127u : vel) * 258, c = (((x * x) >> 15) * 52429) >> 15;   /* 1.6 x^2 */
    if (c > 32767)
        c = 32767;
    return 32767 - (((32767 - c) * (int32_t)S[cr_touch_vsens > 2u ? 0u : cr_touch_vsens]) >> 15);
}
static int32_t cr_touch_at_amt(void)
{
    static const int8_t A[3] = {40, 24, 63};
    return A[cr_touch_atsens > 2u ? 0u : cr_touch_atsens];
}
/* the VEL source's value (Q15): the velocity as it is with Key Touch Fixed, the law above with it on */
static int32_t cr_touch_vsrc(uint32_t vel) { return cr_touch_mode ? cr_touch_gain(vel) : (int32_t)vel * 258; }
/* Expression (the editor's EXPR screen of every engine, docs/VELOCITY.md): the matrix's slots 3 and 4 are the sound's
 * velocity and aftertouch routings, SRC fixed to VEL and AT, DST and AMT the sound's (saved with it). A slot whose SRC
 * is still 0 (every sound until its EXPR cell is turned) takes the default with Key Touch on: VEL -> AMP at the full
 * law (Dynamic and Velocity + Aftertouch), AT -> CUT by Aftertouch Sens (Velocity + Aftertouch); with Key Touch Fixed
 * nothing, as before. An explicit slot applies whatever Key Touch says (MIDI's velocity and aftertouch reach the same
 * sources), so a sound may route them itself; DST OFF switches its default off. */
#define P_MVEL_SRC P_M3SRC
#define P_MAT_SRC P_M4SRC
#define CR_TOUCH_VEL_DEF_AMT 63
#define MS_BIPOLAR(s) ((s) == MS_LFO || (s) == MS_KEY || (s) == MS_RAND)

/* the track parameter of a per-block destination */
static uint32_t mod_param(uint32_t d)
{
    static const uint8_t ID[MD_E1] = {[MD_PAN] = P_PAN, [MD_DIST] = P_DIST, [MD_CHO] = P_CHOR, [MD_DLY] = P_DLY,
                                      [MD_REV] = P_REV, [MD_RATE] = P_LRATE, [MD_VIB] = P_LD_PIT};
    return d >= MD_E1 ? P_E0 + d - MD_E1 : ID[d];
}

static struct {                  /* a part's matrix in its block (mix_part) */
    uint8_t on;                  /* a slot is active: track_render calls mod_voice */
    uint8_t amp;                 /* an AMP slot: the voice gain applies */
    uint8_t nv, nk;              /* voice terms, per-block parameters held */
    int32_t pit, cut, shp, gain; /* per voice, from the per-track sources (gain Q15) */
    uint8_t vsrc[NMSLOT + 1u], vdst[NMSLOT + 1u];   /* (+ 1: the default VEL -> AMP) */
    int8_t vamt[NMSLOT + 1u];
    uint8_t kid[NMSLOT];         /* per-block: the parameter, its stored value */
    int16_t keep[NMSLOT];
} mod_tab[NPART];                  /* per part: ChoralRoot's core 1 renders part 1 while core 0 renders part 0
                                  * (docs/DUALCORE.md); one part at a time otherwise, as before */
#define MODP(t) mod_tab[(t) - trk]

static uint32_t mod_seed = 0x2545F491u;
static int16_t mod_rand(void)    /* RAND of a note-on: xorshift32, bipolar */
{
    mod_seed ^= mod_seed << 13;
    mod_seed ^= mod_seed >> 17;
    mod_seed ^= mod_seed << 5;
    return (int16_t)(mod_seed >> 16);
}

static int32_t mod_key(uint32_t note) { return clamp(((int32_t)note - 60) * 512, -32767, 32767); }

/* source s of the track: the per-track ones, the per-voice ones of the latest note-on */
CR_HOT_CORE static int32_t mod_tsrc(const track_t *t, uint32_t s, int32_t lfo)
{
    switch (s) {
    case MS_LFO:
        return lfo;
    case MS_ENV:
        return t->m_env;
    case MS_VEL:
        return cr_touch_vsrc(t->m_vel);
    case MS_KEY:
        return mod_key(t->m_key);
    case MS_RAND:
        return t->m_rnd;
    case MS_MODW:
        return t->mw * 258;
    case MS_AT:
        return t->at * 258;
    default:
        return (127 - t->ex_off) * 258;
    }
}

/* AMP: the gain (Q15, 0..32767) of source x (bipolar: as 0..1) at amount a */
static int32_t mod_gain(uint32_t s, int32_t x, int32_t a)
{
    int32_t u = MS_BIPOLAR(s) ? (x + 32768) >> 1 : x;
    return clamp(32767 - (a > 0 ? ((32767 - u) * a) >> 6 : (u * -a) >> 6), 0, 32767);
}

/* a per-voice destination d by source value x, amount a */
CR_HOT_CORE static void mod_voice_add(uint32_t s, uint32_t d, int32_t x, int32_t a, int32_t *pit, int32_t *cut, int32_t *shp,
                          int32_t *gain)
{
    if (d == MD_PITCH)
        *pit += (x * a * 3) >> 15;
    else if (d == MD_CUT)
        *cut += (x * a) >> 7;
    else if (d == MD_SHP)
        *shp += (x * a) >> 7;
    else
        *gain = mulq15(*gain, mod_gain(s, x, a));
}

/* before a part's block (fx.c mix_part): the per-track offsets, the per-block destinations into t->p.
 * 0 = no slot active (then nothing changed) */
CR_HOT_CORE static __attribute__((noinline)) int mod_begin(track_t *t)
{
    const int16_t *p = t->p;
    int32_t lfo, off[NMSLOT];
    uint32_t k, j;
    int vel_def = cr_touch_mode != CR_TOUCH_FIXED && !p[P_MVEL_SRC];       /* the defaults (cr_touch_vsrc, above) */
    int at_def = cr_touch_mode == CR_TOUCH_VEL_AT && t->at && !p[P_MAT_SRC];
    MODP(t).on = 0;
    for (k = 0; k < NMSLOT; k++)
        if (p[P_M1SRC + 3u * k] && p[P_M1DST + 3u * k] && p[P_M1AMT + 3u * k])
            break;
    if (k == NMSLOT && !vel_def && !at_def)
        return 0;
    lfo = mulq15(t->lfo_val, t->lfo_fade);              /* (the LFO of the block before: track_render ticks it) */
    MODP(t).on = 1;
    MODP(t).amp = 0;
    MODP(t).nv = MODP(t).nk = 0;
    MODP(t).pit = MODP(t).cut = MODP(t).shp = 0;
    MODP(t).gain = 32767;
    for (; k < NMSLOT; k++) {
        uint32_t s = (uint32_t)p[P_M1SRC + 3u * k], d = (uint32_t)p[P_M1DST + 3u * k];
        int32_t a = p[P_M1AMT + 3u * k], x;
        if (!s || !d || !a || s >= MS_N || d >= MD_N)
            continue;
        if (d <= MD_AMP) {                              /* per voice */
            MODP(t).amp |= d == MD_AMP;
            if (MS_VOICE(s)) {
                MODP(t).vsrc[MODP(t).nv] = (uint8_t)s;
                MODP(t).vdst[MODP(t).nv] = (uint8_t)d;
                MODP(t).vamt[MODP(t).nv++] = (int8_t)a;
            } else {
                mod_voice_add(s, d, mod_tsrc(t, s, lfo), a, &MODP(t).pit, &MODP(t).cut, &MODP(t).shp, &MODP(t).gain);
            }
            continue;
        }
        {                                               /* per block: AMT 64 = the whole range */
            uint32_t id = mod_param(d);
            const param_desc_t *pd = id >= P_E0 ? &ENGINES[t->engine]->edit[id - P_E0] : &TP[id];
            x = mod_tsrc(t, s, lfo);
            for (j = 0; j < MODP(t).nk && MODP(t).kid[j] != id; j++)
                ;
            if (j == MODP(t).nk) {
                MODP(t).kid[j] = (uint8_t)id;
                MODP(t).keep[j] = p[id];
                off[j] = 0;
                MODP(t).nk++;
            }
            off[j] += (((x * a) >> 6) * (pd->max - pd->min)) >> 15;
        }
    }
    if (vel_def) {
        MODP(t).amp = 1;
        MODP(t).vsrc[MODP(t).nv] = MS_VEL;
        MODP(t).vdst[MODP(t).nv] = MD_AMP;
        MODP(t).vamt[MODP(t).nv++] = CR_TOUCH_VEL_DEF_AMT;
    }
    if (at_def)
        mod_voice_add(MS_AT, MD_CUT, t->at * 258, cr_touch_at_amt(), &MODP(t).pit, &MODP(t).cut, &MODP(t).shp,
                      &MODP(t).gain);
    for (j = 0; j < MODP(t).nk; j++) {
        uint32_t id = MODP(t).kid[j];
        const param_desc_t *pd = id >= P_E0 ? &ENGINES[t->engine]->edit[id - P_E0] : &TP[id];
        t->p[id] = (int16_t)clamp(MODP(t).keep[j] + off[j], pd->min, pd->max);
    }
    return 1;
}

/* after the part's block (when MODP(t).on): the stored values back */
CR_HOT_CORE static __attribute__((noinline)) void mod_end(track_t *t)
{
    uint32_t j;
    for (j = 0; j < MODP(t).nk; j++)
        t->p[MODP(t).kid[j]] = MODP(t).keep[j];
    MODP(t).on = 0;
}

/* a voice's modulation (voice.c track_render, when MODP(t).on), onto its vmod_t m as track_render made it:
 * pitch (the increment again, with the fine factor fine as there), cutoff and shape (clamped to what the
 * fixed routings can reach), the amplitude (and v->env_out, the next block's start). env: its envelope */
CR_HOT_CORE static __attribute__((noinline)) void mod_voice(track_t *t, voice_t *v, vmod_t *m, int32_t fine)
{
    int32_t pit = MODP(t).pit, cut = MODP(t).cut, shp = MODP(t).shp, gain = MODP(t).gain, env = m->envq15;
    uint32_t k;
    if (v == &t->v[t->m_vi])
        t->m_env = env;                                 /* ENV of the latest note, for per-block destinations */
    for (k = 0; k < MODP(t).nv; k++) {
        uint32_t s = MODP(t).vsrc[k];
        int32_t x = s == MS_ENV ? env : s == MS_VEL ? cr_touch_vsrc(v->mvel) : s == MS_KEY ? mod_key(v->note) : v->mrnd;
        mod_voice_add(s, MODP(t).vdst[k], x, MODP(t).vamt[k], &pit, &cut, &shp, &gain);
    }
    if (pit) {
        m->pitch16 = clamp(m->pitch16 + pit, 0, 2047);
        m->inc = pitch_inc(m->pitch16);
        if (fine)
            m->inc += (uint32_t)((int32_t)(m->inc >> 12) * fine);
    }
    m->cutoff = clamp(m->cutoff + cut, -150 * 256, 150 * 256);
    m->shape = clamp(m->shape + shp, -62 * 256, 190 * 256);
    if (MODP(t).amp) {
        m->amp1 = mulq15(m->amp1, gain);
        v->env_out = m->amp1;
    }
}

/* a note-on of track t (voice.c trk_note_on): the per-voice sources of the latest note */
static void mod_note(track_t *t, uint32_t note, uint32_t vel)
{
    t->m_vel = (uint8_t)vel;
    t->m_key = (uint8_t)note;
    t->m_rnd = mod_rand();
}

/* a MIDI controller for track t (seq.c events_block): CC1 / CC11 / channel aftertouch; CC121 resets them. Also
 * CC2 breath, CC4 foot, CC5 portamento time and CC65 portamento for FM6 (its DX7 controllers; Melodee's) */
static __attribute__((noinline)) void mod_midi(track_t *t, uint32_t st, uint32_t d1, uint32_t d2)
{
    if (st == 0xD0u) {
        t->at = (uint8_t)d1;
    } else if (st == 0xB0u) {
        if (d1 == 1u)
            t->mw = (uint8_t)d2;
        else if (d1 == 11u)
            t->ex_off = (uint8_t)(127u - d2);
        else if (d1 == 2u)
            t->breath = (uint8_t)d2;
        else if (d1 == 4u)
            t->foot = (uint8_t)d2;
        else if (d1 == 65u)
            t->porta = (uint8_t)(d2 >= 64u);
        else if (d1 == 5u)
            fm6_fn_set((uint32_t)(t - trk), FN_PTIME, (int32_t)d2);   /* FM6's portamento time (the track's) */
        else if (d1 == 121u)
            t->mw = t->at = t->ex_off = t->breath = t->foot = t->porta = 0;
    }
}

/* the name of destination value v for track t (UI, <= 5 characters): E1..E8 by the engine's labels (of the
 * engine the UI shows), "E5" for a parameter the engine does not use */
static const char *mod_dst_name(const track_t *t, int32_t v)
{
    v = clamp(v, 0, MD_N - 1);
    if (v >= MD_E1) {
        const char *l = track_desc(t, P_E0 + (uint32_t)(v - MD_E1))->label;
        if (l && l[0] && l[0] != '-')
            return l;
    }
    return N_MDST[v];
}
