/* SPDX-License-Identifier: GPL-3.0-only */
/* ===========================================================================================
 * THE KEYBOARD MAP of the FM-1 emulator. Change it here; --help and the panel hints follow.
 *
 * Physical key positions (SDL scancodes: the US-layout names, whatever the system layout is).
 * Firmware note keys: index = MIDI note - 53 (0 = F3 .. 26 = G5).
 *
 *   note keys, white   A  S  D  F  G  H  J  K  L  ;  '  ]   = C4 D4 E4 F4 G4 A4 B4 C5 D5 E5 F5 G5 (keys 7 ..)
 *   note keys, black   W  E  T  Y  U  O  P                   = C#4 D#4 F#4 G#4 A#4 C#5 D#5   (Ableton Live's;
 *                      R and I, in the gaps, are unmapped; F#5 has no key: the mouse)
 *   chord block        F1 F2 F3 F4                       = F#3 G#3 A#3 C#4 (keys 1 3 5 8)
 *                      2  3  4  5                        = F3  G3  A3  C4  (keys 0 2 4 7)
 *                      Tab                               = B3 (key 6: ChoralRoot's LOCK, the chord mod key)
 *                      (the keys are the firmware's: Options > Chord Keys says what they do. Classic: F1..F4 DIM MIN
 *                      MAJ SUS, 2..5 6 m7 M7 9, Tab LOCK. FM-1, docs/CHORD-LAYOUT.md: F1 F2 F3 DIM MIN MAJ, F2 + F3
 *                      SUS, 2 3 4 Tab 6 m7 M7 9, F4 / W and 5 / A the roots C#4 / C4, F8 (LFO) LOCK, F10 (GLO) held +
 *                      F8 LATCH)
 *   octave             Z X (and Esc Return)              = OCT- OCT+;  End = both = panic
 *   buttons, top row   F5 F6 F7 F8 F9 F10                = FX SEL ENV LFO EDIT GLO
 *            bottom    7  8  9  0  -  =                  = HOME SAVE ARP SEQ PLAY REC
 *   knobs              Page Down / Page Up: select the next / previous of SELECT KNOB1..KNOB4 (wraps);
 *                      Up / Down turn the selected one (one detent per press, repeats; Shift held: GLO held around
 *                      each detent = OPT snap in the editor, OPT's second function outside it); MASTER, PRESETS,
 *                      ALGORITHM: mouse (wheel over a knob turns it, click selects it, vertical drag turns it)
 *   tools              ` show / hide the big LCD view above the panel (window)
 *                      PrintScreen (F13 on a Mac keyboard) LCD screenshot (build/emu/shot_NNN.png)
 *                      Insert record every LCD frame (build/emu/rec/NNNN.ppm), again to stop
 *                      F12 print the fm1_in state
 * (On a Mac keyboard the F keys may need fn.)
 * =========================================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "emu.h"
#include "emu_hooks.h"

const keymap_t KEYMAP[] = {
    /* the chord block (first: the panel hint of keys 7 and 8 stays "5" / "F4") */
    {SDL_SCANCODE_F1, KM_KEY, 1, "F1"},
    {SDL_SCANCODE_F2, KM_KEY, 3, "F2"},
    {SDL_SCANCODE_F3, KM_KEY, 5, "F3"},
    {SDL_SCANCODE_F4, KM_KEY, 8, "F4"},
    {SDL_SCANCODE_2, KM_KEY, 0, "2"},
    {SDL_SCANCODE_3, KM_KEY, 2, "3"},
    {SDL_SCANCODE_4, KM_KEY, 4, "4"},
    {SDL_SCANCODE_5, KM_KEY, 7, "5"},
    {SDL_SCANCODE_TAB, KM_KEY, 6, "TAB"},         /* B3: LOCK (the chord mod key) */
    /* note keys, Ableton Live's layout: white C4 = key 7 upward */
    {SDL_SCANCODE_A, KM_KEY, 7, "A"},
    {SDL_SCANCODE_S, KM_KEY, 9, "S"},
    {SDL_SCANCODE_D, KM_KEY, 11, "D"},
    {SDL_SCANCODE_F, KM_KEY, 12, "F"},
    {SDL_SCANCODE_G, KM_KEY, 14, "G"},
    {SDL_SCANCODE_H, KM_KEY, 16, "H"},
    {SDL_SCANCODE_J, KM_KEY, 18, "J"},
    {SDL_SCANCODE_K, KM_KEY, 19, "K"},
    {SDL_SCANCODE_L, KM_KEY, 21, "L"},
    {SDL_SCANCODE_SEMICOLON, KM_KEY, 23, ";"},
    {SDL_SCANCODE_APOSTROPHE, KM_KEY, 24, "'"},
    {SDL_SCANCODE_RIGHTBRACKET, KM_KEY, 26, "]"},
    /* note keys, black */
    {SDL_SCANCODE_W, KM_KEY, 8, "W"},
    {SDL_SCANCODE_E, KM_KEY, 10, "E"},
    {SDL_SCANCODE_T, KM_KEY, 13, "T"},
    {SDL_SCANCODE_Y, KM_KEY, 15, "Y"},
    {SDL_SCANCODE_U, KM_KEY, 17, "U"},
    {SDL_SCANCODE_O, KM_KEY, 20, "O"},
    {SDL_SCANCODE_P, KM_KEY, 22, "P"},
    /* octave: Z / X (first: the panel hint), Esc / Return too; End = both = panic */
    {SDL_SCANCODE_Z, KM_BTN, EMU_B_OCTDN, "Z"},
    {SDL_SCANCODE_X, KM_BTN, EMU_B_OCTUP, "X"},
    {SDL_SCANCODE_ESCAPE, KM_BTN, EMU_B_OCTDN, "ESC"},
    {SDL_SCANCODE_RETURN, KM_BTN, EMU_B_OCTUP, "RETURN"},
    {SDL_SCANCODE_END, KM_OCTBOTH, 0, "END"},
    /* buttons, the FM-1's two rows */
    {SDL_SCANCODE_F5, KM_BTN, EMU_B_FX, "F5"},
    {SDL_SCANCODE_F6, KM_BTN, EMU_B_SEL, "F6"},
    {SDL_SCANCODE_F7, KM_BTN, EMU_B_ENV, "F7"},
    {SDL_SCANCODE_F8, KM_BTN, EMU_B_LFO, "F8"},
    {SDL_SCANCODE_F9, KM_BTN, EMU_B_EDIT, "F9"},
    {SDL_SCANCODE_F10, KM_BTN, EMU_B_GLO, "F10"},
    {SDL_SCANCODE_7, KM_BTN, EMU_B_HOME, "7"},
    {SDL_SCANCODE_8, KM_BTN, EMU_B_SAVE, "8"},
    {SDL_SCANCODE_9, KM_BTN, EMU_B_ARP, "9"},
    {SDL_SCANCODE_0, KM_BTN, EMU_B_SEQ, "0"},
    {SDL_SCANCODE_MINUS, KM_BTN, EMU_B_PLAY, "-"},
    {SDL_SCANCODE_EQUALS, KM_BTN, EMU_B_REC, "="},
    /* knobs: Page Down / Up cycle SELECT KNOB1..KNOB4; MASTER, PRESETS, ALGORITHM: the mouse */
    {SDL_SCANCODE_PAGEDOWN, KM_CYCLE, +1, "PGDN"},
    {SDL_SCANCODE_PAGEUP, KM_CYCLE, -1, "PGUP"},
    {SDL_SCANCODE_LSHIFT, KM_SHIFT, 0, "LSHIFT"},
    {SDL_SCANCODE_RSHIFT, KM_SHIFT, 0, "RSHIFT"},
    {SDL_SCANCODE_UP, KM_TURN, +1, "UP"},
    {SDL_SCANCODE_DOWN, KM_TURN, -1, "DOWN"},
    /* tools */
    {SDL_SCANCODE_GRAVE, KM_LCDVIEW, 0, "`"},
    {SDL_SCANCODE_PRINTSCREEN, KM_SHOT, 0, "PRTSC"},
    {SDL_SCANCODE_F13, KM_SHOT, 0, "F13"},
    {SDL_SCANCODE_INSERT, KM_RECORD, 0, "INSERT"},
    {SDL_SCANCODE_F12, KM_DUMP, 0, "F12"},
};
const int KEYMAP_N = (int)(sizeof KEYMAP / sizeof KEYMAP[0]);

const char *const EMU_BTN_NAME[] = {"FX", "SEL", "ENV", "LFO", "EDIT", "GLO", "HOME", "SAVE",
                                    "ARP", "SEQ", "PLAY", "REC", "OCT-", "OCT+"};
const char *const EMU_ENC_NAME[] = {"SELECT", "ALGORITHM", "PRESETS", "KNOB1", "KNOB2", "KNOB3", "KNOB4", "MASTER"};

void emu_note_name(int key, char *out)
{
    static const char *const N[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    int m = 53 + key;
    sprintf(out, "%s%d", N[m % 12], m / 12 - 1);
}

const keymap_t *keymap_find(SDL_Scancode sc)
{
    int i;
    for (i = 0; i < KEYMAP_N; i++)
        if (KEYMAP[i].sc == sc)
            return &KEYMAP[i];
    return NULL;
}

const char *keymap_hint(uint8_t kind, int idx)
{
    int i;
    for (i = 0; i < KEYMAP_N; i++)
        if (KEYMAP[i].kind == kind && KEYMAP[i].idx == idx)
            return KEYMAP[i].cap;
    return NULL;
}

/* no computer key mapped twice: exit 2 at start-up on a duplicate (called from main) */
void keymap_check(void)
{
    int i, j, bad = 0;
    for (i = 0; i < KEYMAP_N; i++)
        for (j = i + 1; j < KEYMAP_N; j++)
            if (KEYMAP[i].sc == KEYMAP[j].sc || !strcasecmp(KEYMAP[i].cap, KEYMAP[j].cap)) {
                fprintf(stderr, "keymap.c: key %s mapped twice (entries %d and %d)\n", KEYMAP[i].cap, i, j);
                bad = 1;
            }
    if (bad)
        exit(2);
}

void keymap_help(void)
{
    int i;
    char n[8];
    printf("Keyboard map (tools/emu/keymap.c; physical US-layout positions):\n");
    for (i = 0; i < KEYMAP_N; i++) {
        const keymap_t *k = &KEYMAP[i];
        printf("  %-8s ", k->cap);
        switch (k->kind) {
        case KM_KEY:
            emu_note_name(k->idx, n);
            printf("key %-4s (firmware key %d, MIDI %d)\n", n, k->idx, 53 + k->idx);
            break;
        case KM_BTN: printf("button %s\n", EMU_BTN_NAME[k->idx]); break;
        case KM_OCTBOTH: printf("OCT- and OCT+ together\n"); break;
        case KM_CYCLE: printf("select the %s knob of SELECT KNOB1..KNOB4 (Up / Down turn it)\n", k->idx > 0 ? "next" : "previous"); break;
        case KM_SELECT: printf("select knob %s (Up / Down turn it)\n", EMU_ENC_NAME[k->idx]); break;
        case KM_SHIFT: printf("Shift + Up / Down: OPT snap in the editor (the firmware's SHIFT: GLO held); outside it, OPT's second function\n"); break;
        case KM_TURN: printf("turn the selected knob %s\n", k->idx > 0 ? "clockwise (+1)" : "counter-clockwise (-1)"); break;
        case KM_SHOT: printf("screenshot of the LCD -> build/emu/shot_NNN.png\n"); break;
        case KM_RECORD: printf("record every LCD frame -> build/emu/rec/NNNN.ppm (toggle)\n"); break;
        case KM_DUMP: printf("print the fm1_in state\n"); break;
        case KM_LCDVIEW: printf("show / hide the big LCD view above the panel\n"); break;
        }
    }
    printf("  mouse    click a key / button: press it (right-click: latch it down, again to release)\n"
           "           wheel over a knob: one detent per notch; click a knob: select it; drag it up / down: turn\n"
           "  Cmd-Q or closing the window quits (and prints the audio / frame timing).\n");
}
