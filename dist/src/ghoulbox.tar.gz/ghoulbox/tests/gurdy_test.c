/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 GHOULBOX (on Felucca by Leo Kuroshita, Hügelton Instruments) */
/* GURDY (src/eng_gurdy.c, engine 14) on the host, the voices through voice.c as on the device:
 * 1. the bourdon sits on DRN whatever key is played (D2 under C4 and under G4, as loud), and moves with DRN
 *    (C2 at DRN C, no D2); the chanterelle follows the key.
 * 2. the trompette's strokes: at COUP 1/8 (120 BPM) the buzz (> 2 kHz) is loud at each stroke's start and gone
 *    by its end; at HOLD it is steady; at BUZZ 0 there is none.
 * 3. one wheel: two keys held sound one voice.
 * 4. the corners: every EDIT at 0 and 127, notes C1 .. C7: bounded, no DC.
 * 5. cost (instructions per sample of a voice; the Linux counter).
 * 6. GHOULBOX's crank (COUP CRANK): the speed from SELECT's clicks (their input frames), slowing and stopped; wrist
 *    strokes on a sharp speed-up only; the sound: silent with the key held and the wheel still, louder and brighter
 *    turning faster, silent again once stopped and back without a new note; a stroke's buzz; WHL shown as GEAR. */
#define main hostsim_main
#include "hostsim.c"
#undef main
#ifdef __linux__
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <unistd.h>
#endif

static int bad;
static void check(const char *what, int ok)
{
    printf("gurdy: %-96s %s\n", what, ok ? "ok" : "FAIL");
    bad += !ok;
}
static uint64_t instr_now(void)
{
#ifdef __linux__
    static int fd = -2;
    uint64_t v;
    if (fd == -2) {
        struct perf_event_attr a;
        memset(&a, 0, sizeof a);
        a.type = PERF_TYPE_HARDWARE;
        a.size = sizeof a;
        a.config = PERF_COUNT_HW_INSTRUCTIONS;
        a.exclude_kernel = a.exclude_hv = 1;
        fd = (int)syscall(SYS_perf_event_open, &a, 0, -1, -1, 0);
    }
    if (fd >= 0 && read(fd, &v, sizeof v) == (ssize_t)sizeof v)
        return v;
#endif
    return 0;
}

#define N (2u * FS / CTL * CTL)
static double y[N];

/* EDIT e (DRN DLVL 5TH WHL BUZZ COUP BODY WOBL), notes held, N samples after 0.2 s */
static void play(const int16_t *e, const uint8_t *notes, uint32_t nn)
{
    static int32_t b[CTL];
    uint32_t i, k;
    host_tracks_init();
    song.g[G_BPM] = 120;
    host_preset(&trk[0], ENGI_GURDY, 0);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = e[i];
    trk[0].p[P_ATK] = 0;
    trk[0].p[P_SUS] = 127;
    trk[0].p[P_REL] = 10;
    trk[0].p[P_VOICE] = V_POLY;
    for (i = 0; i < nn; i++)
        trk_note_on(&trk[0], notes[i], 100);
    for (i = 0; i < FS / 5u / CTL; i++)
        track_render(&trk[0], b, CTL);
    for (i = 0; i < N; i += CTL) {
        track_render(&trk[0], b, CTL);
        for (k = 0; k < CTL; k++)
            y[i + k] = b[k] / 32768.0;
    }
}
static double tone(double hz)                           /* Goertzel magnitude of y at hz, Hann window */
{
    double w = 2 * M_PI * hz / FS, c = 2 * cos(w), s0, s1 = 0, s2 = 0;
    uint32_t i;
    for (i = 0; i < N; i++) {
        s0 = y[i] * (0.5 - 0.5 * cos(2 * M_PI * i / N)) + c * s1 - s2;
        s2 = s1;
        s1 = s0;
    }
    return sqrt(s1 * s1 + s2 * s2 - c * s1 * s2) / N;
}
static double midi_hz(int n) { return 440.0 * pow(2, (n - 69) / 12.0); }

/* the crank: HURDY GURDY at COUP CRANK (BUZZ b), D4 held; render ms into y (from 0), its RMS and its RMS > 2 kHz
 * (a first difference, twice) over the last tail ms */
static void crank_reset(void)
{
    memset((void *)&crank, 0, sizeof crank);
    memset(&crank_m, 0, sizeof crank_m);
}
static void crank_start(int16_t b)
{
    host_tracks_init();
    host_preset(&trk[0], ENGI_GURDY, 0);
    trk[0].p[P_E5] = (int16_t)GURDY_CRANK;
    trk[0].p[P_E4] = b;
    trk[0].p[P_E7] = 0;                                 /* (no WOBL: steady levels) */
    trk[0].p[P_ATK] = 0;
    trk[0].p[P_SUS] = 127;
    trk_note_on(&trk[0], 62, 100);
}
static double crank_run(uint32_t ms, uint32_t tail, double *hf)
{
    static int32_t b[CTL];
    uint32_t i, k, n = FS * ms / 1000u / CTL * CTL, t0 = FS * tail / 1000u < n ? n - FS * tail / 1000u : 1u;
    double sum = 0, sh = 0, d0 = 0, d1;
    for (i = 0; i < n && i < N; i += CTL) {
        track_render(&trk[0], b, CTL);
        for (k = 0; k < CTL; k++)
            y[i + k] = b[k] / 32768.0;
    }
    for (i = t0; i < n; i++) {
        sum += y[i] * y[i];
        d1 = y[i] - y[i - 1];
        sh += (d1 - d0) * (d1 - d0);
        d0 = d1;
    }
    if (hf)
        *hf = sqrt(sh / (n - t0));
    return sqrt(sum / (n - t0));
}
/* the trompette's strokes (COUP 1/8 at 120 BPM): energy > 2 kHz in each stroke's first quarter vs its second
 * half, in dB, for D4 held */
static double stroke_ratio(const int16_t *e)
{
    static const uint8_t D4[1] = {62};
    uint32_t per = (uint32_t)FS * 60u / 120u / 2u, i, k;
    double on = 0, off = 0, prev = 0, hp;
    play(e, D4, 1);
    for (i = 1; i < N; i++) {                           /* > 2 kHz: a first difference, twice */
        hp = y[i] - y[i - 1];
        k = (i + FS / 5u) % per;                        /* (the strokes count from the note-on, 0.2 s before y) */
        *(k < per / 4u ? &on : k > per / 2u ? &off : &prev) += (hp - prev) * (hp - prev);
        prev = hp;
    }
    return 10 * log10((on / (per / 4.0)) / (off / (per / 2.0 - 1) + 1e-30) + 1e-30);
}

int main(void)
{
    char what[200];
    uint32_t i;
    {   /* 1 */
        static const int16_t E[8] = {2, 127, 0, 60, 0, 0, 0, 0};
        static const int16_t EC[8] = {0, 127, 0, 60, 0, 0, 0, 0};
        static const uint8_t C4[1] = {60}, G4[1] = {67};
        double d1, d2, m1, m2, c2, dd;
        play(E, C4, 1); d1 = tone(midi_hz(38)); m1 = tone(midi_hz(60));
        play(E, G4, 1); d2 = tone(midi_hz(38)); m2 = tone(midi_hz(67));
        play(EC, C4, 1); c2 = tone(midi_hz(36)); dd = tone(midi_hz(38));
        snprintf(what, sizeof what, "drone: D2 under C4 %.4f, under G4 %.4f; the keys' own C4 %.4f, G4 %.4f", d1, d2, m1, m2);
        check(what, d1 > 0.01 && fabs(20 * log10(d1 / d2)) < 1.0 && m1 > 0.01 && m2 > 0.01);
        snprintf(what, sizeof what, "  DRN C: C2 %.4f, D2 %.4f (gone)", c2, dd);
        check(what, c2 > 0.01 && dd < c2 / 30);
    }
    {   /* 2 */
        int16_t e[8] = {2, 0, 0, 0, 127, 2, 0, 0};       /* buzz alone (no bourdon, no fifth, little melody) */
        static const int16_t HG[8] = {2, 90, 50, 80, 70, 2, 70, 40};   /* HURDY GURDY's own: drones and all */
        double ratio[4];
        uint32_t m;
        for (m = 0; m < 3u; m++) {
            e[5] = m == 1u ? 0 : 2;                     /* 1/8, HOLD, 1/8 at BUZZ 0 */
            e[4] = m == 2u ? 0 : 127;
            ratio[m] = stroke_ratio(e);
        }
        ratio[3] = stroke_ratio(HG);
        snprintf(what, sizeof what, "trompette: stroke start vs end, the buzz %.1f dB at COUP 1/8, %.1f dB at HOLD, %.1f dB at BUZZ 0",
                 ratio[0], ratio[1], ratio[2]);
        check(what, ratio[0] >= 10.0 && fabs(ratio[1]) < 2.0 && fabs(ratio[2]) < 2.0);
        snprintf(what, sizeof what, "  1.3: heard over the drones (HURDY GURDY, BUZZ 70): %.1f dB at each stroke", ratio[3]);
        check(what, ratio[3] >= 6.0);
    }
    {   /* 3 */
        static const int16_t E[8] = {2, 90, 50, 80, 60, 2, 70, 40};
        static const uint8_t TWO[2] = {60, 64};
        play(E, TWO, 2);
        snprintf(what, sizeof what, "one wheel: two keys held, %u voice(s) sounding", busy_now());
        check(what, busy_now() == 1u);
    }
    {   /* 4 */
        int32_t worst = 0;
        double dc = 0;
        uint32_t c, n;
        for (c = 0; c < 256u; c++) {
            int16_t e[8];
            uint8_t note[1];
            for (i = 0; i < 8u; i++)
                e[i] = (int16_t)((c >> i) & 1u ? (i == 0u ? 11 : i == 5u ? 4 : 127) : 0);
            for (n = 24; n <= 96; n += 36) {
                double sum = 0, pk = 0;
                note[0] = (uint8_t)n;
                play(e, note, 1);
                for (i = 0; i < N; i++) {
                    sum += y[i];
                    pk = fabs(y[i]) > pk ? fabs(y[i]) : pk;
                }
                worst = (int32_t)(pk * 32768) > worst ? (int32_t)(pk * 32768) : worst;
                dc = fabs(sum / N) > dc ? fabs(sum / N) : dc;
            }
        }
        snprintf(what, sizeof what, "corners: 256 EDIT corners x C1 / C4 / C7: peak %d, worst DC %.2f %% of full scale", worst, dc * 100);
        check(what, worst < 4 * 32768 && dc < 0.02);
    }
    {   /* 5 */
        static const int16_t E[8] = {2, 90, 50, 80, 70, 2, 70, 40};
        static const uint8_t D4[1] = {62};
        static int32_t b[CTL];
        uint64_t i0;
        play(E, D4, 1);
        i0 = instr_now();
        for (i = 0; i < 4u * FS / CTL; i++)
            track_render(&trk[0], b, CTL);
        if (i0) {
            double c = (double)(instr_now() - i0) / (4.0 * FS);
            snprintf(what, sizeof what, "cost: a buzzing voice, %.0f instructions per sample (limit 300; one voice: poly 1)", c);
            check(what, c <= 300);
        } else
            printf("gurdy: cost: no instruction counter on this host\n");
    }
    {   /* 6 */
        uint32_t fr = 1000, c, ok;
        double slow, fast, hs, hf, stopped, back, on, off;
        crank_reset();
        crank_clicks(1, fr);
        ok = crank.speed == 0u;                         /* from a stop: no speed yet */
        for (c = 0; c < 10u; c++)
            crank_clicks(1, fr += 25u);                 /* a click every 25 frames: 36.4 clicks/s */
        ok &= crank.speed == 909u * 16u / 25u && crank.strokes == 0u;
        crank_clicks(3, fr += 75u);                     /* three in one read: the same speed */
        ok &= crank.speed == 909u * 16u / 25u;
        snprintf(what, sizeof what, "crank: speed from the clicks' frames, %u x 1/16 clicks/s (36.4 / s), a read of three the same", crank.speed);
        check(what, ok);
        crank_idle(fr + 20u);
        ok = crank.speed == 909u * 16u / 25u;           /* not late yet */
        crank_idle(fr + 50u);
        ok &= crank.speed == 909u * 16u / 50u;          /* late: at most one click over the time since */
        crank_idle(fr + CRANK_STOP + 1u);
        check("  slowing: at most a click over the time since the last; 300 ms without one: stopped", ok && crank.speed == 0u);

        crank_reset();
        for (c = 0, fr = 1000; c < 40u; c++)
            crank_clicks(1, fr += 25u);
        ok = crank.strokes == 0u;                       /* steady: none */
        for (c = 0; c < 4u; c++)
            crank_clicks(1, fr += 8u);                  /* a wrist stroke: 3 x the speed for 4 clicks */
        ok &= crank.strokes == 1u;                      /* one (the rest of the burst inside 70 ms) */
        for (c = 0; c < 12u; c++)
            crank_clicks(1, fr += 25u);
        ok &= crank.strokes == 1u;
        for (c = 0; c < 4u; c++)
            crank_clicks(1, fr += 8u);
        ok &= crank.strokes == 2u;
        crank_idle(fr + CRANK_STOP + 1u);
        fr += CRANK_STOP + 100u;
        for (c = 0; c < 10u; c++)
            crank_clicks(1, fr += 8u);                  /* from a stop straight to 113 clicks/s: a start, no stroke */
        snprintf(what, sizeof what, "  strokes: a sharp speed-up is one (one per burst, 70 ms apart), steady and a start from a stop none (%u)",
                 crank.strokes);
        check(what, ok && crank.strokes == 2u);

        crank_reset();
        crank_start(0);
        stopped = crank_run(300, 100, 0);
        ok = stopped < 1e-6 && busy_now() == 1u;
        crank.speed = 15u * 16u;                        /* 15 clicks/s, GEAR 80 (full at 30) */
        slow = crank_run(300, 100, &hs);
        crank.speed = 40u * 16u;
        fast = crank_run(300, 100, &hf);
        snprintf(what, sizeof what, "  sound: still with D4 held silent (%g); 15 clicks/s %.4f, 40 / s %.4f (+%.1f dB), brighter (> 2 kHz %+.1f dB)",
                 stopped, slow, fast, 20 * log10(fast / slow), 20 * log10((hf / fast) / (hs / slow)));
        check(what, ok && slow > 0.005 && fast > slow * 1.2 && hf / fast > hs / slow);
        crank.speed = 0;
        stopped = crank_run(500, 50, 0);
        ok = stopped < 1e-6 && busy_now() == 1u;
        crank.speed = 40u * 16u;
        back = crank_run(150, 50, 0);
        snprintf(what, sizeof what, "  stopped: %g 0.45 s on (silent), the key still held; turning again without a new note: %.4f", stopped, back);
        check(what, ok && back > fast / 2);

        crank_start(127);
        crank.speed = 40u * 16u;
        crank_run(500, 100, 0);
        crank.strokes++;                                /* a stroke */
        crank_run(40, 40, &on);
        crank_run(150, 40, &off);                       /* (150 ms on: the burst gone) */
        snprintf(what, sizeof what, "  a stroke: the buzz > 2 kHz %.1f dB over the wheel's alone, after it", 20 * log10(on / off));
        check(what, on > off * 2);
        ok = str_eq(track_desc(&trk[0], P_E3)->label, "GEAR") && str_eq(track_desc(&trk[0], P_E5)->names[5], "CRANK") &&
             track_desc(&trk[0], P_E5)->max == 5;
        trk[0].p[P_E5] = 2;
        check("  COUP's sixth value CRANK (append-only); WHL shown as GEAR at CRANK, WHL at 1/8",
              ok && str_eq(track_desc(&trk[0], P_E3)->label, "WHL"));
        crank_reset();
    }
    printf("%s\n", bad ? "GURDY TEST FAILED" : "gurdy test passed");
    return bad != 0;
}
