/* SPDX-License-Identifier: GPL-3.0-only */
/* (GHOULBOX 2.1: the lessons as 2.1 works: PHRASES on SAVE, the MIXER on HOME, LFO DEST after LFO 2, the SYSTEM tab
 * the fifth, and RESTORE LAST, ON since 2.1, OFF for the lessons' fresh starts and ON again at the end) */
/* GHOULBOX lessons: a lesson played on the firmware's own input, audio AND screen code (tests/ui_render.c), as a
 * player would, one action at a time: buttons tapped and held and knobs turned go through ui_input() like the panel's.
 *   build/host/lesson_render N OUT.wav [FRAMES.rgb]   -> the mix (and the screen, 240x240 RGB24 at 30 fps);
 *   OUT.wav.acts: one line per action, "t0<TAB>t1<TAB>control<TAB>kind (tap, hold, turn+ clockwise, turn-, say)<TAB>step<TAB>step title<TAB>what to do",
 *   for tools/make_lesson_video.py (the sword points at the control). Not a test. */
#define UI_RENDER_NO_MAIN
#include "ui_render.c"

/* the controls, as the video names them: buttons (panel.c B_*), then the knobs (EN_*), then none */
enum { C_FX, C_SCL, C_ENV, C_LFO, C_EDIT, C_GLO, C_HOME, C_SAVE, C_ARP, C_SEQ, C_PLAY, C_REC, C_OCTDN, C_OCTUP,
       C_SELECT, C_ALGO, C_PRESETS, C_K1, C_K2, C_K3, C_K4, C_POWER, C_KEY, C_NONE };
static const char *const CNAME[] = {"FX", "SCL", "ENV", "LFO", "EDIT", "GLO", "HOME", "SAVE", "ARP", "SEQ", "PLAY",
                                    "REC", "OCT-", "OCT+", "SELECT", "ALGORITHM", "PRESETS", "KNOB1", "KNOB2",
                                    "KNOB3", "KNOB4", "POWER", "KEY", "-"};
enum { K_TAP, K_HOLD, K_TURN, K_SAY, K_KEY, K_GLOKEY };   /* K_KEY: key arg held dur - 0.6 s; K_GLOKEY: GLO held,
                                                             * key arg tapped (a mute, track until-1 toggles) */
/* what an action turns or taps until: */
enum { U_CLICKS, U_TRACK, U_SOUND, U_PICK, U_PAGE, U_ROW, U_TAB, U_VALUE, U_SCENE, U_RESTORE };   /* U_RESTORE: arg 1 OFF */
typedef struct {
    uint8_t ctl, kind, until; int16_t arg;            /* U_CLICKS: arg clicks (signed); U_VALUE: the knob's value */
    const char *name;                                  /* U_SOUND / U_PAGE: the name to reach */
    const char *say;                                   /* the caption */
    float dur;                                         /* seconds on screen (0: 3.5) */
} act_t;
typedef struct { const char *title; const act_t *acts; } lstep_t;
typedef struct { const lstep_t *steps; float tail; uint8_t scene; } lesson_t;   /* scene: the one the FM-1 has */

#define TAP(c, s) {c, K_TAP, U_CLICKS, 1, 0, s, 0}
#define TAPS(c, page, s) {c, K_TAP, U_PAGE, 0, page, s, 0}
#define HOLD(c, s) {c, K_HOLD, U_CLICKS, 0, 0, s, 0}
#define TURN_TO(c, u, a, nm, s) {c, K_TURN, u, a, nm, s, 0}
#define SAY(c, s, d) {c, K_SAY, U_CLICKS, 0, 0, s, d}
#define KEY(k, s, d) {C_KEY, K_KEY, U_CLICKS, k, 0, s, d}
#define MUTE(k, trk, s) {C_KEY, K_GLOKEY, (trk) + 1, k, 0, s, 0}
#define END {C_NONE, 0, 0, 0, 0, 0, 0}

/* ---------------------------------------------------------------- LESSON 1: THE DRONE */
#define PEDAL 16                                       /* PATTERNS[16]: one low D, held (engines.c) */
static const act_t L1_START[] = {
    HOLD(C_HOME, "Hold HOME: the menu opens"),
    TURN_TO(C_ALGO, U_TAB, MTAB_SYSTEM, 0, "Turn ALGORITHM to the SYSTEM tab"),
    TURN_TO(C_PRESETS, U_ROW, MI_SCENE, 0, "PRESETS picks the row: SCENE is the first"),
    TURN_TO(C_OCTUP, U_SCENE, 4, 0, "Press OCT+ until it says BLANK"),
    TURN_TO(C_PRESETS, U_ROW, MI_RESTORE, 0, "Turn PRESETS down to RESTORE LAST"),
    TURN_TO(C_OCTDN, U_RESTORE, 1, 0, "Press OCT- until it says OFF: a fresh start"),
    TAP(C_HOME, "Tap HOME to close the menu"),
    SAY(C_POWER, "Switch the FM-1 off, then on again", 5), END};
static const act_t L1_NOTE[] = {
    TURN_TO(C_ALGO, U_TRACK, 3, 0, "Turn ALGORITHM until the red number is 4"),
    SAY(C_NONE, "Track 4 already has the sound DRONE WHEEL", 4),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, PEDAL, 0, "Turn KNOB 1 to 17 PEDAL"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    TAP(C_PLAY, "Press PLAY"),
    SAY(C_NONE, "One low D that never stops: a drone", 6), END};
static const act_t L1_TUNE[] = {
    TAP(C_EDIT, "Tap EDIT"),
    SAY(C_K1, "KNOB 1 is DRN, the drone's note: D. Leave it", 4.5f),
    TURN_TO(C_K3, U_VALUE, 0, 0, "Turn KNOB 3 (5TH) all the way down"),
    SAY(C_NONE, "Listen: one note alone", 5),
    TURN_TO(C_K3, U_VALUE, 110, 0, "Turn KNOB 3 back up"),
    SAY(C_NONE, "An A joins below: an open fifth", 6), END};
static const act_t L1_BREATHE[] = {
    TURN_TO(C_K4, U_VALUE, 127, 0, "Turn KNOB 4 (WHL) up: lean on the wheel"),
    SAY(C_NONE, "Brighter and rougher", 4),
    TURN_TO(C_K4, U_VALUE, 45, 0, "Turn KNOB 4 back down"),
    TAP(C_EDIT, "Tap EDIT again"),
    TURN_TO(C_K4, U_VALUE, 0, 0, "Turn KNOB 4 (WOBL) down: dead still"),
    SAY(C_NONE, "Listen: no movement at all", 4.5f),
    TURN_TO(C_K4, U_VALUE, 90, 0, "Turn KNOB 4 up: the wheel wanders"),
    SAY(C_NONE, "Now it breathes", 5), END};
static const act_t L1_HALL[] = {
    TAP(C_FX, "Tap FX"),
    TURN_TO(C_K4, U_VALUE, 0, 0, "Turn KNOB 4 (REV) all the way down: dry"),
    SAY(C_NONE, "Listen: a small, close sound", 4.5f),
    TURN_TO(C_K4, U_VALUE, 120, 0, "Turn KNOB 4 up: into the reverb"),
    TAPS(C_FX, "REVERB", "Tap FX until REVERB"),
    TURN_TO(C_K2, U_VALUE, 20, 0, "Turn KNOB 2 (SIZE) down: a stone chamber"),
    SAY(C_NONE, "A small room", 4),
    TURN_TO(C_K2, U_VALUE, 127, 0, "Turn KNOB 2 all the way up: a cathedral"),
    SAY(C_NONE, "The drone fills the hall", 6), END};
static const act_t L1_VOICE[] = {
    TURN_TO(C_ALGO, U_TRACK, 2, 0, "Turn ALGORITHM to 3"),
    TURN_TO(C_PRESETS, U_SOUND, 0, "LOW DRONE", "Turn PRESETS to LOW DRONE"),
    TAPS(C_HOME, "MIXER", "Tap HOME until the MIXER"),
    TURN_TO(C_K1, U_VALUE, 0, 0, "Turn KNOB 1 (LEVEL) all the way down"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, PEDAL, 0, "KNOB 1 is already on 17 PEDAL: LOW DRONE picks it"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    TAPS(C_HOME, "MIXER", "Tap HOME until the MIXER again"),
    TURN_TO(C_K1, U_VALUE, 92, 0, "Turn KNOB 1 slowly up: a sung D below"),
    SAY(C_NONE, "Two drones", 5), END};
static const act_t L1_CAVE[] = {
    TURN_TO(C_ALGO, U_TRACK, 1, 0, "Turn ALGORITHM to 2"),
    TURN_TO(C_PRESETS, U_SOUND, 0, "CAVE WIND", "Turn PRESETS to CAVE WIND"),
    TAPS(C_HOME, "MIXER", "Tap HOME until the MIXER"),
    TURN_TO(C_K1, U_VALUE, 0, 0, "Turn KNOB 1 (LEVEL) all the way down"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, PEDAL, 0, "Turn KNOB 1 to 17 PEDAL"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    TAPS(C_HOME, "MIXER", "Tap HOME until the MIXER again"),
    TURN_TO(C_K1, U_VALUE, 70, 0, "Turn KNOB 1 up until you barely hear it"),
    SAY(C_NONE, "Two drones, a hall and the wind: dark ambient", 9),
    TAP(C_PLAY, "Press PLAY to stop"), END};
static const lstep_t L1_STEPS[] = {
    {"Start empty", L1_START}, {"One low note", L1_NOTE}, {"Tune it", L1_TUNE}, {"Let it breathe", L1_BREATHE},
    {"Into the hall", L1_HALL}, {"A second voice", L1_VOICE}, {"The cave", L1_CAVE}, {0, 0}};

/* the drone again, for the lessons after the first (the FM-1 forgets what was not saved when it is switched off) */
static const act_t SETUP[] = {
    HOLD(C_HOME, "Hold HOME: the menu"),
    TURN_TO(C_ALGO, U_TAB, MTAB_SYSTEM, 0, "Turn ALGORITHM to the SYSTEM tab"),
    TURN_TO(C_PRESETS, U_ROW, MI_SCENE, 0, "PRESETS to the SCENE row"),
    TURN_TO(C_OCTUP, U_SCENE, 4, 0, "SCENE should say BLANK (OCT+ / OCT- change it)"),
    TURN_TO(C_PRESETS, U_ROW, MI_RESTORE, 0, "PRESETS down to RESTORE LAST"),
    TURN_TO(C_OCTDN, U_RESTORE, 1, 0, "RESTORE LAST should say OFF (OCT- sets it)"),
    TAP(C_HOME, "Tap HOME to close the menu"),
    SAY(C_POWER, "Switch the FM-1 off, then on again", 5),
    TURN_TO(C_ALGO, U_TRACK, 3, 0, "Turn ALGORITHM to 4: DRONE WHEEL"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, PEDAL, 0, "Turn KNOB 1 to 17 PEDAL"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    TAP(C_PLAY, "Press PLAY: the drone from Lesson 1"),
    SAY(C_NONE, "Now we build on it", 4), END};

/* ---------------------------------------------------------------- LESSON 2: A MELODY IN THE DARK */
#define BALLAD 14
static const act_t L2_GURDY[] = {
    TURN_TO(C_ALGO, U_TRACK, 0, 0, "Turn ALGORITHM to 1: HURDY GURDY"),
    SAY(C_NONE, "Track 1 is a hurdy-gurdy with no notes yet", 4.5f), END};
static const act_t L2_SCALE[] = {
    TAP(C_SCL, "Tap SCL: the scale"),
    TURN_TO(C_K1, U_VALUE, 2, 0, "KNOB 1 (ROOT) to D"),
    TURN_TO(C_K2, U_VALUE, 2, 0, "KNOB 2 (SCL) to MIN: minor"),
    TURN_TO(C_K3, U_VALUE, 2, 0, "Turn KNOB 3 (QNT) to WHITE"),
    SAY(C_NONE, "Now the white keys play only D minor: no wrong notes", 5.5f),
    SAY(C_NONE, "The black keys go silent. Middle C plays D", 5), END};
static const act_t L2_PLAY[] = {
    SAY(C_NONE, "Play slowly. The sword shows each key", 4),
    KEY(14, "A", 1.6f), KEY(12, "G", 1.4f), KEY(11, "F", 1.4f), KEY(9, "E", 1.4f), KEY(7, "D: home", 2.6f),
    KEY(11, "F", 1.4f), KEY(9, "E", 1.4f), KEY(6, "C, below", 1.6f), KEY(7, "D: home", 3.0f),
    SAY(C_NONE, "A falling line over the drone: that is the sound", 5.5f), END};
static const act_t L2_BALLAD[] = {
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, BALLAD, 0, "Turn KNOB 1 to 15 BALLAD"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    SAY(C_NONE, "A melody that plays itself, over the drone", 12), END};
static const act_t L2_BUZZ[] = {
    TAPS(C_EDIT, "EDIT 2", "Tap EDIT twice"),
    TURN_TO(C_K1, U_VALUE, 0, 0, "Turn KNOB 1 (BUZZ) all the way down"),
    SAY(C_NONE, "A plain, sad string", 6),
    TURN_TO(C_K1, U_VALUE, 110, 0, "Turn KNOB 1 back up: the buzzing bridge"),
    TURN_TO(C_K2, U_VALUE, 0, 0, "Turn KNOB 2 (COUP) to HOLD: it buzzes all the time"),
    SAY(C_NONE, "A constant snarl", 5),
    TURN_TO(C_K2, U_VALUE, 2, 0, "KNOB 2 back to 1/8: the buzz strikes in time"),
    SAY(C_NONE, "The hurdy-gurdy's dance rhythm", 7),
    TAP(C_PLAY, "Press PLAY to stop"), END};
static const lstep_t L2_STEPS[] = {
    {"Set up", SETUP}, {"The hurdy-gurdy", L2_GURDY}, {"No wrong notes", L2_SCALE}, {"Play a phrase", L2_PLAY},
    {"A melody that plays itself", L2_BALLAD}, {"The buzzing bridge", L2_BUZZ}, {0, 0}};

/* ---------------------------------------------------------------- LESSON 3: THE CRYPT PAD */
#define DIRGE 13
static const act_t L3_CHORDS[] = {
    TURN_TO(C_ALGO, U_TRACK, 1, 0, "Turn ALGORITHM to 2: CRYPT PAD"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, DIRGE, 0, "Turn KNOB 1 to 14 DIRGE"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    SAY(C_NONE, "Slow chords: D minor, B flat, C, D minor", 12), END};
static const act_t L3_ATTACK[] = {
    TAP(C_ENV, "Tap ENV: the envelope"),
    TURN_TO(C_K1, U_VALUE, 0, 0, "Turn KNOB 1 (ATK) all the way down"),
    SAY(C_NONE, "Each chord starts at once", 7),
    TURN_TO(C_K1, U_VALUE, 110, 0, "Turn KNOB 1 up: each chord swells in"),
    SAY(C_NONE, "Like a choir taking a breath", 8), END};
static const act_t L3_RELEASE[] = {
    TURN_TO(C_K4, U_VALUE, 0, 0, "Turn KNOB 4 (REL) all the way down"),
    SAY(C_NONE, "Each chord stops dead", 7),
    TURN_TO(C_K4, U_VALUE, 120, 0, "Turn KNOB 4 up: they ring on and blur"),
    SAY(C_NONE, "Into the hall", 7), END};
static const act_t L3_HARP[] = {
    TURN_TO(C_K3, U_VALUE, 0, 0, "Turn KNOB 3 (SUS) all the way down"),
    TURN_TO(C_K1, U_VALUE, 0, 0, "Turn KNOB 1 (ATK) all the way down"),
    TURN_TO(C_K2, U_VALUE, 40, 0, "Turn KNOB 2 (DEC) to about a third"),
    SAY(C_NONE, "The same sound, plucked: a harp", 9),
    TURN_TO(C_K3, U_VALUE, 127, 0, "Turn KNOB 3 (SUS) all the way up"),
    TURN_TO(C_K1, U_VALUE, 90, 0, "Turn KNOB 1 (ATK) up again: a pad"),
    SAY(C_NONE, "Four knobs: from a harp to a choir", 6), END};
static const act_t L3_ALL[] = {
    TURN_TO(C_ALGO, U_TRACK, 0, 0, "Turn ALGORITHM to 1: HURDY GURDY"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, BALLAD, 0, "Turn KNOB 1 to 15 BALLAD"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    SAY(C_NONE, "Drone, chords and melody: a dungeon, by hand", 14),
    TAP(C_PLAY, "Press PLAY to stop"), END};
static const lstep_t L3_STEPS[] = {
    {"Set up", SETUP}, {"Chords", L3_CHORDS}, {"How a note starts", L3_ATTACK}, {"How a note ends", L3_RELEASE},
    {"Pad into harp", L3_HARP}, {"All together", L3_ALL}, {0, 0}};

/* ---------------------------------------------------------------- LESSON 4: MOVEMENT */
#define CHANT 15
static const act_t L4_MONKS[] = {
    TURN_TO(C_ALGO, U_TRACK, 2, 0, "Turn ALGORITHM to 3: MONKS"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, CHANT, 0, "Turn KNOB 1 to 16 CHANT"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    SAY(C_NONE, "Low voices: steady, unmoving", 8), END};
static const act_t L4_TREMOLO[] = {
    TAPS(C_LFO, "LFO DEST", "Tap LFO until LFO DEST"),
    SAY(C_NONE, "The LFO is a slow, hidden hand on a knob", 5),
    TURN_TO(C_K4, U_VALUE, 80, 0, "Turn KNOB 4 (AMP) up: the voices pulse"),
    SAY(C_NONE, "Loudness rising and falling: tremolo", 6),
    TAPS(C_LFO, "LFO", "Tap LFO until LFO (the rate page)"),
    TURN_TO(C_K1, U_VALUE, 25, 0, "Turn KNOB 1 (RATE) down: slower, like breathing"),
    SAY(C_NONE, "Slow movement feels alive", 8), END};
static const act_t L4_VIBRATO[] = {
    TURN_TO(C_ALGO, U_TRACK, 0, 0, "Turn ALGORITHM to 1: HURDY GURDY"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, BALLAD, 0, "Turn KNOB 1 to 15 BALLAD"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    TAPS(C_LFO, "LFO DEST", "Tap LFO until LFO DEST"),
    TURN_TO(C_K1, U_VALUE, 10, 0, "Turn KNOB 1 (PIT) up a little: vibrato"),
    SAY(C_NONE, "The pitch wavers, as a player's hand would", 7),
    TAPS(C_LFO, "LFO", "Tap LFO until LFO"),
    TURN_TO(C_K4, U_VALUE, 70, 0, "Turn KNOB 4 (FADE) up: the vibrato comes in late"),
    SAY(C_NONE, "Each long note starts plain, then sings", 10), END};
static const act_t L4_TIDE[] = {
    TURN_TO(C_ALGO, U_TRACK, 1, 0, "Turn ALGORITHM to 2: CRYPT PAD"),
    TAPS(C_SAVE, "PHRASES", "Tap SAVE until PHRASES"),
    TURN_TO(C_K1, U_PICK, DIRGE, 0, "Turn KNOB 1 to 14 DIRGE"),
    TAP(C_OCTUP, "Press OCT+ to load it"),
    TAPS(C_LFO, "LFO", "Tap LFO until LFO"),
    TURN_TO(C_K1, U_VALUE, 5, 0, "Turn KNOB 1 (RATE) almost all the way down"),
    TAPS(C_LFO, "LFO DEST", "Tap LFO until LFO DEST"),
    TURN_TO(C_K2, U_VALUE, 40, 0, "Turn KNOB 2 (FLT) up: the pad darkens and brightens"),
    SAY(C_NONE, "A slow tide, over many seconds", 14),
    TAP(C_PLAY, "Press PLAY to stop"), END};
static const lstep_t L4_STEPS[] = {
    {"Set up", SETUP}, {"The monks", L4_MONKS}, {"Tremolo", L4_TREMOLO}, {"Vibrato", L4_VIBRATO},
    {"A slow tide", L4_TIDE}, {0, 0}};

/* ---------------------------------------------------------------- LESSON 5: THE CASSETTE */
static const act_t L5_DUNGEON[] = {
    HOLD(C_HOME, "Hold HOME: the menu"),
    TURN_TO(C_ALGO, U_TAB, MTAB_SYSTEM, 0, "Turn ALGORITHM to the SYSTEM tab"),
    TURN_TO(C_PRESETS, U_ROW, MI_SCENE, 0, "PRESETS to the SCENE row"),
    TURN_TO(C_OCTUP, U_SCENE, 0, 0, "Press OCT- until SCENE says DUNGEON"),
    TAP(C_HOME, "Tap HOME to close the menu"),
    SAY(C_POWER, "Switch the FM-1 off, then on again", 5),
    TAP(C_PLAY, "Press PLAY"),
    SAY(C_NONE, "The whole DUNGEON scene: everything from Lessons 1 to 4", 10), END};
static const act_t L5_BALANCE[] = {
    TAPS(C_HOME, "MIXER", "Tap HOME until the MIXER"),
    TURN_TO(C_ALGO, U_TRACK, 3, 0, "Turn ALGORITHM to 4: the drone"),
    TURN_TO(C_K1, U_VALUE, 84, 0, "Turn KNOB 1 (LEVEL) down a little"),
    SAY(C_NONE, "The drone sits under everything", 5),
    TURN_TO(C_ALGO, U_TRACK, 0, 0, "Turn ALGORITHM to 1: the melody"),
    TURN_TO(C_K1, U_VALUE, 112, 0, "Turn KNOB 1 up a little: the melody in front"),
    SAY(C_NONE, "Balance is most of mixing", 6), END};
static const act_t L5_TAPE[] = {
    TAPS(C_FX, "TAPE", "Tap FX until TAPE"),
    TURN_TO(C_K1, U_VALUE, 100, 0, "Turn KNOB 1 (TAPE) up: a worn cassette"),
    SAY(C_NONE, "Wow, flutter and hiss: the tape stretches", 9),
    TURN_TO(C_K2, U_VALUE, 35, 0, "Turn KNOB 2 (CRSH) up a little: grit"),
    SAY(C_NONE, "Like a cheap sampler. A little goes a long way", 8), END};
static const act_t L5_MUTES[] = {
    SAY(C_NONE, "Hold GLO: the first four black keys mute tracks 1 to 4", 5.5f),
    MUTE(1, 0, "Hold GLO, tap the 1st black key: the melody drops out"),
    SAY(C_NONE, "Only the bed is left", 7),
    MUTE(5, 2, "Hold GLO, tap the 3rd black key: the monks go"),
    SAY(C_NONE, "Strip it down to pad and drone", 7),
    MUTE(5, 2, "Again: the monks return"),
    MUTE(1, 0, "Again on the 1st: the melody returns"),
    SAY(C_NONE, "Building up and breaking down: a live performance", 9), END};
static const act_t L5_RECORD[] = {
    SAY(C_NONE, "Connect the FM-1 to a computer with a USB data cable", 5),
    SAY(C_NONE, "It shows up as an audio input: record it in any app", 5),
    SAY(C_NONE, "Audacity is free. The tape and hiss are in the recording", 6),
    TAP(C_PLAY, "Press PLAY to stop"),
    SAY(C_NONE, "You have made a dungeon-synth piece", 6), END};
static const act_t L5_KEEP[] = {
    HOLD(C_HOME, "Hold HOME: the menu"),
    TURN_TO(C_ALGO, U_TAB, MTAB_SYSTEM, 0, "Turn ALGORITHM to the SYSTEM tab"),
    TURN_TO(C_PRESETS, U_ROW, MI_RESTORE, 0, "Turn PRESETS to RESTORE LAST"),
    TURN_TO(C_OCTUP, U_RESTORE, 0, 0, "Press OCT+ until it says ON"),
    TAP(C_HOME, "Tap HOME to close the menu"),
    SAY(C_NONE, "From now on the FM-1 wakes up with what you were playing", 6), END};
static const lstep_t L5_STEPS[] = {
    {"The whole dungeon", L5_DUNGEON}, {"Balance", L5_BALANCE}, {"The cassette", L5_TAPE},
    {"Play the mutes", L5_MUTES}, {"Record it", L5_RECORD}, {"Keep your music", L5_KEEP}, {0, 0}};

static const lesson_t LESSONS[] = {{L1_STEPS, 9, 0} /* (a new FM-1: DUNGEON) */, {L2_STEPS, 8, 4}, {L3_STEPS, 8, 4}, {L4_STEPS, 8, 4}, {L5_STEPS, 8, 4}};

/* ---------------------------------------------------------------- the player */
static FILE *wav, *vid;
static uint32_t now, next_frame;                       /* samples */
static int32_t lit_slot = -1;                          /* the card of the knob being turned */
static int dark;                                       /* the FM-1 switched off: a black screen */

static void frame_out(void)
{
    static uint8_t rgb[240u * 240u * 3u];
    uint32_t i;
    ui.bpm_t = 0;
    if (lit_slot >= 0) {
        ui.hot_col = (uint8_t)lit_slot;
        ui.hot_t = 20;
    }
    ui_draw();
    if (dark)
        memset(host_screen, 0, sizeof host_screen);
    for (i = 0; i < 240u * 240u; i++) {
        uint16_t c = swap16(host_screen[i]);
        rgb[3 * i] = (uint8_t)((c >> 11) * 255u / 31u);
        rgb[3 * i + 1] = (uint8_t)(((c >> 5) & 63u) * 255u / 63u);
        rgb[3 * i + 2] = (uint8_t)((c & 31u) * 255u / 31u);
    }
    if (vid)
        fwrite(rgb, 1, sizeof rgb, vid);
}

static void run(float sec)                             /* the device runs: audio, the input loop, the screen */
{
    uint32_t end = now + (uint32_t)(sec * FS), i;
    int32_t o[2 * CTL];
    while (now < end) {
        mix_block(o, CTL);
        for (i = 0; i < CTL; i++) {
            wav_put(wav, o[2 * i], o[2 * i + 1]);
            scope_buf[scope_w++ & (SCOPE_N - 1u)] = (int16_t)clamp(o[2 * i], -32768, 32767);   /* as audio.c */
        }
        now += CTL;
        if (now >= next_frame) {                       /* 30 fps; the input loop twice a frame, as on the device */
            fm1_ms = (uint32_t)((uint64_t)now * 1000u / FS);
            host_ticks += 16000u;
            ui_input();
            host_ticks += 16000u;
            ui_input();
            frame_out();
            next_frame += FS / 30u;
        }
    }
}

static void btn(uint32_t b, int down)
{
    if (down) {
        fm1_in.buttons |= 1u << panel.btn[b];
        host_pressed |= 1u << panel.btn[b];
    } else
        fm1_in.buttons &= ~(1u << panel.btn[b]);
}

static int16_t *knob_value(uint32_t slot)
{
    int16_t *v = 0;
    const page_t *pg = &PAGES[ui.page];
    if (ui.home || ui.menu)
        return 0;
    if (pg->scope == SC_TRK) {                         /* the MIXER: LEVEL PAN REV MUTE of the track */
        static const uint8_t ID[4] = {P_LEVEL, P_PAN, P_REV, P_MUTE};
        return &TSEL->p[ID[slot]];
    }
    page_desc(pg, slot, &v);
    return v;
}

static int reached(const act_t *a)
{
    int16_t *v;
    switch (a->until) {
    case U_TRACK: return song.sel == a->arg;
    case U_SOUND: { char b[24] = {0}; sound_name(TSEL, b); return !strcmp(b, a->name); }
    case U_PICK: return ui.ppick == a->arg;
    case U_PAGE: return !ui.home && !ui.menu && !strcmp(PAGES[ui.page].title, a->name);
    case U_ROW: return ui.menu && ui.menu_sel == a->arg;
    case U_TAB: return menu_tab() == (uint32_t)a->arg;
    case U_SCENE: return ui_scene == a->arg;
    case U_RESTORE: return ((ui_prefs & PREF_RESTORE_OFF) != 0u) == (a->arg != 0);
    case U_VALUE: return (v = knob_value((uint32_t)(a->ctl - C_K1))) && *v == a->arg;
    }
    return 0;
}

static int direction(const act_t *a)                   /* which way to turn to get there */
{
    int16_t *v;
    if (a->until == U_VALUE && (v = knob_value((uint32_t)(a->ctl - C_K1))))
        return *v < a->arg ? 1 : -1;
    if (a->until == U_TRACK)
        return song.sel < a->arg ? 1 : -1;
    if (a->until == U_PICK)
        return ui.ppick < a->arg ? 1 : -1;
    if (a->until == U_ROW)                             /* (the menu keeps a tab's last row: either way) */
        return ui.menu_sel < a->arg ? 1 : -1;
    return 1;
}

static void stuck(uint32_t step, const act_t *a)
{
    fprintf(stderr, "step %u: \"%s\" never got there\n", step, a->say);
    exit(1);
}

static void act(FILE *log, uint32_t step, const char *title, const act_t *a)
{
    float t0 = now / (float)FS, dur = a->dur > 0 ? a->dur : 3.5f, spent;
    uint32_t n = 0;
    int way = 0;                                       /* the turn's first click: 1 clockwise (up), -1 counter */
    uint32_t used = a->ctl;                            /* the control the hand used */
    char cname[16];
    run(0.6f);                                         /* the sword arrives, then the hand moves */
    spent = 0.6f;
    if ((a->kind == K_TAP && a->until == U_CLICKS) || a->kind == K_HOLD) {
        float held = a->kind == K_HOLD ? 1.0f : 0.15f;
        btn(a->ctl, 1); run(held); btn(a->ctl, 0); spent += held;
    } else if (a->kind == K_TAP || (a->kind == K_TURN && (a->ctl == C_OCTUP || a->ctl == C_OCTDN))) {   /* tap until it shows */
        while (!reached(a)) {
            uint32_t b = a->until == U_SCENE && ui_scene > a->arg ? C_OCTDN : a->ctl;   /* (the menu: either way) */
            if (n++ > 12u)
                stuck(step, a);
            used = b;
            btn(b, 1); run(0.15f); btn(b, 0); run(0.7f); spent += 0.85f;
        }
    } else if (a->kind == K_KEY) {                     /* a key held, as a player would */
        float held = dur - 0.6f - 0.05f;
        fm1_in.notes |= 1u << a->arg;
        run(held);
        fm1_in.notes &= ~(1u << a->arg);
        spent += held;
    } else if (a->kind == K_GLOKEY) {                  /* GLO held for its layer, a black key: a track's mute */
        int16_t was = trk[a->until - 1].p[P_MUTE];
        btn(C_GLO, 1); run(0.9f);
        fm1_in.notes |= 1u << a->arg; run(0.2f); fm1_in.notes &= ~(1u << a->arg); run(0.4f);
        btn(C_GLO, 0);
        spent += 1.5f;
        if (trk[a->until - 1].p[P_MUTE] == was)
            stuck(step, a);
    } else if (a->kind == K_TURN) {
        uint32_t e = (uint32_t)(a->ctl - C_SELECT + EN_SELECT);
        float click;                                   /* a value sweeps; a list steps, the first steps seen */
        if (a->ctl >= C_K1)
            lit_slot = a->ctl - C_K1;
        while (!reached(a)) {
            if (n++ > 400u)
                stuck(step, a);
            click = a->until == U_VALUE ? 0.025f : n <= 3u ? 0.4f : 0.08f;
            int d = direction(a);                      /* (a fast sweep may overshoot by a click and come back) */
            if (!way)
                way = d;
            host_enc[panel.enc[e]] += d * panel.dir[e];
            run(click);
            spent += click;
        }
    }
    if (a->ctl == C_POWER) {                           /* off, a breath, on: as at power-on (RESTORE LAST OFF: the scene
                                                        * chosen; ON: the last session, as it was) */
        run(0.6f);
        dark = 1;
        run(1.4f);
        if (ui_prefs & PREF_RESTORE_OFF)
            gb_scene_load(ui_scene);
        rev_clear();
        hall_clear();
        dark = 0;
        spent += 2.0f;
    }
    if (spent < dur)
        run(dur - spent);
    lit_slot = -1;
    if (a->ctl == C_KEY)
        snprintf(cname, sizeof cname, "%sKEY%d", a->kind == K_GLOKEY ? "GLO+" : "", a->arg);
    else
        snprintf(cname, sizeof cname, "%s", CNAME[used]);
    fprintf(log, "%.3f\t%.3f\t%s\t%s\t%u\t%s\t%s\n", t0, now / (float)FS, cname,
            a->kind == K_TAP ? "tap" : a->kind == K_HOLD ? "hold" : a->kind == K_KEY ? "key" :
            a->kind == K_GLOKEY ? "glokey" : a->kind != K_TURN ? "say" :
            a->ctl == C_OCTUP || a->ctl == C_OCTDN ? "tap" : way > 0 ? "turn+" : way < 0 ? "turn-" : "turn0", step, title,
            a->say);
}

int main(int argc, char **argv)
{
    uint32_t n = argc > 1 ? (uint32_t)atoi(argv[1]) : 1u, s, i, total;
    const char *path = argc > 2 ? argv[2] : "lesson.wav";
    const lesson_t *L;
    FILE *log;
    char lpath[600];
    if (n < 1u || n > sizeof LESSONS / sizeof LESSONS[0])
        return 2;
    L = &LESSONS[n - 1u];
    vid = argc > 3 ? fopen(argv[3], "wb") : 0;
    rep = fopen("/dev/null", "w");                     /* (ui_render's lint hooks report here) */
    ui_power_on();
    pal(UI_CRYPT_INDEX);
    memset(trk, 0, sizeof trk);
    host_tracks_init();
    song.batt_raw = 600;
    usb.config = 0;
    ui_scene = L->scene;                               /* the FM-1 as the lesson before left it, stopped */
    if (n > 1u)                                        /* (lesson 1 set RESTORE LAST OFF; a 2.1 FM-1 starts ON) */
        ui_prefs |= PREF_RESTORE_OFF;
    gb_scene_load(ui_scene);
    rev_clear();
    hall_clear();
    snprintf(lpath, sizeof lpath, "%s.acts", path);
    if (!(wav = fopen(path, "wb")) || !(log = fopen(lpath, "w")))
        return 1;
    wav_hdr(wav, 0);                                   /* (the length is written at the end) */
    run(1.5f);
    for (s = 0; L->steps[s].title; s++)
        for (i = 0; L->steps[s].acts[i].say; i++) {
            const act_t *a = &L->steps[s].acts[i];
            act(log, s + 1u, L->steps[s].title, a);
        }
    run(L->tail);
    fclose(log);
    total = now;
    fseek(wav, 0, SEEK_SET);
    wav_hdr(wav, total);
    fclose(wav);
    if (vid)
        fclose(vid);
    printf("%s: %.1f s\n", path, total / (double)FS);
    return 0;
}
