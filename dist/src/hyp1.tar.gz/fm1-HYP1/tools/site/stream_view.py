#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Stream view, for livestreams, put into every emulator of the pack (web/emu, lof1, eco1, grav1, cty1):

  the page's emulator on a 16:9 stage (1920 x 1080, scaled to the window): the FM-1 on the left, its screen
  large and sharp on the right, the firmware's name above. Behind it all, a background of each firmware's own,
  following what it plays and shows (the firmware reports its sky, star or theme to the page: web_bg):
    HYP-1   pixel EQ bars and a faint scrolling heatmap of the song, in the screen theme's colours
    LOF-1   soft glows shifting with the music: lows, mids and highs, leaning warmer or cooler with its brightness
    ECO-1   the emulator's sky, its time of day; after a minute untouched, pixel grass fades in, waving in its wind,
            and at night fireflies
    GRAV-1  the star's colour glowing from the centre, vignetting to black; pixel stars drift across
    CTY-1   the sky over the city, its hour and its weather; behind a pixel skyline (taller as the city grows, lit at
            night) the biome's land: mountains, mesas, the volcano smoking, the sea; a siren's colours pulse on it, and
            the lightning flashes
  Subtle, and still (no drift, no scrolling) for those who ask their system for reduced motion. Whatever is pressed glows, whether clicked here
  or played on the real FM-1 through its remote (SEL + GLO); a knob turning gets a ring; a strip under the
  screen names the last few moves. 'FM-1 LINKED' shows while the remote is on.

  Open it with the Stream view button, or the address with ?stream. Its own small bar (Connect MIDI, Exit)
  shows only while the mouse is over the stage, so a window capture doesn't see it.

  python3 tools/site/stream_view.py      ->  the block put in (or replaced in) each emulator's index.html"""
from pathlib import Path

SRC = Path(__file__).resolve().parents[2]
PAGES = [SRC / "web/emu/index.html", SRC / "lof1/web/emu/index.html", SRC / "eco1/web/emu/index.html",
         SRC / "grav1/web/emu/index.html", SRC / "cty1/web/emu/index.html"]
A, B = "/* stream view: begin */", "/* stream view: end */"          # the old single marker (cleared)
CA, CB = "/* stream view css: begin */", "/* stream view css: end */"
JA, JB = "/* stream view js: begin */", "/* stream view js: end */"

CSS = CA + r"""
#stage { display: none; }
body.stream { overflow: hidden; padding: 0; background: #0c0b11; }
body.stream > main, body.stream > footer { display: none; }
body.stream #stage { display: block; position: fixed; left: 50%; top: 50%; width: 1920px; height: 1080px; transform-origin: 50% 50%;
  transform: translate(-50%, -50%) scale(var(--sv-s, .5)); overflow: hidden; color: #f2eade;
  background: radial-gradient(ellipse 62% 62% at 50% 42%, var(--sv-glow), transparent 70%),
              linear-gradient(#1a1824, #0c0b11); font-family: "Barlow Semi Condensed", Barlow, sans-serif; }
#stage .sv-bg, #stage .sv-px, #stage .sv-vig { position: absolute; left: 0; top: 0; width: 1920px; height: 1080px; pointer-events: none; }
#stage .sv-px { image-rendering: pixelated; }
#stage .sv-vig { display: none; background: radial-gradient(ellipse 70% 70% at 50% 50%, transparent 40%, rgba(0, 0, 0, .92) 100%); }
#stage.grav .sv-vig { display: block; }
#stage.grav { background: #000; }
#stage .sv-dev { position: absolute; left: 56px; top: 190px; width: 1100px; }
#stage .sv-dev .device { width: 1100px; }
#stage .sv-big { position: absolute; left: 1174px; top: 128px; width: 704px; height: 704px; border-radius: 30px; background: #0b0a0e;
  border: 2px solid #5a5468; box-sizing: border-box; display: grid; place-items: center; }
#stage .sv-big canvas { width: 660px; height: 660px; image-rendering: pixelated; border-radius: 4px; background: #000; }
#stage .sv-title { position: absolute; left: 56px; top: 44px; display: flex; align-items: center; gap: 22px; }
#stage .sv-bars { display: flex; gap: 6px; } #stage .sv-bars i { display: block; height: 8px; border-radius: 2px; }
#stage .sv-name { font: 700 62px/1 "Barlow Semi Condensed", sans-serif; letter-spacing: .04em; color: var(--sv-acc); }
#stage .sv-tag { font: 500 32px/1.1 "Barlow Semi Condensed", sans-serif; color: #c9bfd8; }
#stage .sv-link { position: absolute; left: 1174px; top: 60px; font: 700 26px/1 "Barlow Semi Condensed", sans-serif; letter-spacing: .1em;
  color: #1a1206; background: #ff9a3c; border-radius: 999px; padding: 10px 22px; box-shadow: 0 0 24px #ff9a3c88; display: none; }
#stage.linked .sv-link { display: block; }
#stage .sv-moves { position: absolute; left: 1174px; top: 860px; width: 704px; display: flex; flex-wrap: nowrap; gap: 10px;
  justify-content: flex-end; overflow: hidden; }
#stage .sv-moves span { flex: none; white-space: nowrap; }
#stage .sv-moves span { font: 600 26px/1 "Barlow Semi Condensed", sans-serif; letter-spacing: .05em; padding: 9px 16px; border-radius: 10px;
  background: #22202c; border: 2px solid var(--sv-acc); color: #f2eade; transition: opacity .6s; }
#stage .sv-moves span.old { opacity: .35; }
#stage .sv-foot { position: absolute; right: 56px; bottom: 34px; font: 600 26px/1 "Barlow Semi Condensed", sans-serif; color: #85799a; letter-spacing: .04em; }
#stage .sv-kofi { position: absolute; right: 56px; bottom: 78px; display: flex; align-items: center; gap: 12px; padding: 10px 20px 10px 14px;
  border-radius: 999px; background: #ff5e5b; color: #fff; font: 700 28px/1 "Barlow Semi Condensed", sans-serif; letter-spacing: .03em;
  text-decoration: none; box-shadow: 0 0 22px #ff5e5b55; }
#stage .sv-kofi b { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 50%; background: #fff; color: #ff5e5b; font-size: 22px; }
#stage .sv-ctl { position: absolute; left: 56px; bottom: 26px; display: flex; gap: 12px; opacity: 0; transition: opacity .25s; }
#stage:hover .sv-ctl { opacity: 1; }
#stage.idle .sv-ctl { opacity: 0; }
#stage.idle, #stage.idle * { cursor: none !important; }
#stage .sv-ctl button { font: 600 22px "Barlow Semi Condensed", sans-serif; color: #f2eade; background: #2a2734; border: 1px solid #6b6380;
  border-radius: 8px; padding: 6px 16px; cursor: pointer; }
body.stream .held .btnface { stroke: #ff9a3c; stroke-width: 6; filter: drop-shadow(0 0 7px #ff9a3c); }
body.stream .held .keyface { stroke: #ff9a3c; stroke-width: 6; filter: drop-shadow(0 0 8px #ff9a3c); }
body.stream .ctl.knob.sv-turn > circle:first-child { stroke: #ff9a3c; stroke-width: 6; filter: drop-shadow(0 0 8px #ff9a3c); }
""" + CB

JS = JA + r"""
(function streamView() {
  const PACK = { "HYP-1": ["#b06cff", "hypnotic techno + acid"], "LOF-1": ["#e8873a", "a lofi groovebox: you play, the band follows"],
                 "ECO-1": ["#76c35e", "a plant plays the FM-1"], "GRAV-1": ["#f2b84b", "a star and its planets play the FM-1"],
                 "CTY-1": ["#e8b931", "a city grows and plays the FM-1"] };
  const NOTE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  const name = (document.querySelector("h1").textContent.match(/[A-Z]+-1/) || ["FM-1"])[0];
  const [acc, tag] = PACK[name] || ["#e8873a", ""];
  const dev = document.getElementById("device"), home = dev.parentNode, after = dev.nextSibling;
  const stage = document.createElement("div");
  stage.id = "stage";
  stage.style.setProperty("--sv-acc", acc);
  stage.style.setProperty("--sv-glow", "rgba(" + [1, 3, 5].map((i) => parseInt(acc.slice(i, i + 2), 16)).join(",") + ",0.24)");
  stage.innerHTML = `<canvas class="sv-bg" width="192" height="108" aria-hidden="true"></canvas><canvas class="sv-px" width="320" height="180" aria-hidden="true"></canvas><div class="sv-vig"></div><div class="sv-title"><div class="sv-bars"><i style="width:70px;background:${acc}"></i><i style="width:34px;background:#7eccc0"></i></div>
    <div><div class="sv-name">${name}</div><div class="sv-tag">${tag}</div></div></div>
    <div class="sv-link">FM-1 LINKED</div><div class="sv-dev"></div><div class="sv-big"><canvas width="240" height="240"></canvas></div>
    <div class="sv-moves"></div><a class="sv-kofi" href="https://ko-fi.com/redtailworks" target="_blank" rel="noopener"><b>☕</b>Support me on ko-fi.com/redtailworks</a>
    <div class="sv-foot">${name}  ·  RedtailWorks  ·  rustypawz.github.io/fm1-HYP1</div>
    <div class="sv-ctl"><button type="button" data-a="midi">Connect MIDI</button><button type="button" data-a="exit">Exit stream view</button></div>`;
  document.body.appendChild(stage);
  const big = stage.querySelector(".sv-big canvas"), bctx = big.getContext("2d"), screen = document.getElementById("screen");
  const moves = stage.querySelector(".sv-moves");
  bctx.imageSmoothingEnabled = false;
  let on = false;
  function fit() { stage.style.setProperty("--sv-s", Math.min(innerWidth / 1920, innerHeight / 1080)); }
  function set(v) {
    on = v;
    document.body.classList.toggle("stream", on);
    if (on) stage.querySelector(".sv-dev").appendChild(dev); else home.insertBefore(dev, after);
    fit();
    try { const u = new URL(location.href); if (on) u.searchParams.set("stream", ""); else u.searchParams.delete("stream"); history.replaceState(null, "", u); } catch {}
  }
  addEventListener("resize", fit);
  let idleT = 0;                                  // the mouse still a moment: its bar and pointer gone (for captures)
  function woke() {
    stage.classList.remove("idle");
    clearTimeout(idleT);
    idleT = setTimeout(() => stage.classList.add("idle"), 2000);
  }
  stage.addEventListener("pointermove", woke);
  stage.addEventListener("pointerdown", woke);
  // THE BACKGROUND: an analyser on the emulator's output (the mix: its first two channels) for the music, and
  // what the firmware reports of its sky, star or theme (window.ambLast.bg, from web_bg). Two canvases: soft
  // (192 x 108, smoothed up) and pixel (320 x 180, kept sharp).
  const bg = stage.querySelector(".sv-bg"), gctx = bg.getContext("2d");
  const px = stage.querySelector(".sv-px"), pctx = px.getContext("2d");
  const still = matchMedia("(prefers-reduced-motion: reduce)");
  stage.classList.toggle("grav", name === "GRAV-1");
  function hueOf(h) {
    const r = parseInt(h.slice(1, 3), 16) / 255, g = parseInt(h.slice(3, 5), 16) / 255, b = parseInt(h.slice(5, 7), 16) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    if (!d) return 0;
    return (mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4) * 60;
  }
  const hue0 = hueOf(acc);
  let an = null, spec = null, binHz = 0, lastBg = 0, lastMove = performance.now();
  const lvl = [0, 0, 0], peak = [1e-4, 1e-4, 1e-4], NB = 40, eq = new Float32Array(NB), eqPeak = new Float32Array(NB);
  let bright = 0.5, loud = 0, topDb = -40;
  function listen() {
    if (an || typeof node === "undefined" || !node) return;
    try {
      an = node.context.createAnalyser();
      an.fftSize = 2048;
      an.smoothingTimeConstant = 0.6;
      an.channelCount = 2;
      an.channelCountMode = "explicit";
      an.channelInterpretation = "discrete";     // the mix only, never the voices apart (channels 3-8)
      node.connect(an);
      spec = new Float32Array(an.frequencyBinCount);
      binHz = node.context.sampleRate / an.fftSize;
    } catch { an = null; }
  }
  function hear(dt) {                             // the music: three bands, brightness, loudness, 40 EQ bands
    an.getFloatFrequencyData(spec);
    const band = [0, 0, 0], eb = new Float32Array(NB).fill(-300);
    let sum = 0, wsum = 0, top = -200;
    for (let i = 1; i < spec.length; i++) {
      const f = i * binHz, db = spec[i], m = Math.pow(10, db / 20);
      if (f < 30 || f > 14000) continue;
      band[f < 250 ? 0 : f < 2000 ? 1 : 2] += m * m;
      sum += m;
      wsum += m * Math.log2(f);
      const k = Math.min(NB - 1, Math.max(0, Math.floor(NB * Math.log2(f / 40) / Math.log2(14000 / 40))));
      if (db > -200) eb[k] = Math.max(eb[k], db);
      top = Math.max(top, db);
    }
    if (sum > 1e-6) {
      const c = Math.min(Math.max((wsum / sum - Math.log2(200)) / Math.log2(15), 0), 1);
      bright += (c - bright) * Math.min(dt * 0.8, 1);
    }
    for (let k = 0; k < 3; k++) {                 // each band against its own recent loudest: quiet music moves too
      const v = Math.sqrt(band[k]);
      peak[k] = Math.max(v, peak[k] * Math.pow(0.5, dt / 8), 1e-4);
      const tgt = Math.min(v / peak[k], 1);
      lvl[k] += (tgt - lvl[k]) * Math.min(dt * (tgt > lvl[k] ? 5 : 0.9), 1);
    }
    topDb = Math.max(top, topDb - dt * 3);        // the EQ's scale: 50 dB under its recent loudest
    const calm = still.matches ? 0.25 : 1;
    for (let k = 0; k < NB; k++) {
      const v = eb[k] > -250 ? Math.min(Math.max((eb[k] - (topDb - 50)) / 50, 0), 1) : 0;
      eq[k] += (v - eq[k]) * Math.min(dt * (v > eq[k] ? 18 : 4) * calm, 1);
      eqPeak[k] = Math.max(eq[k], eqPeak[k] - dt * 0.35);
    }
    loud += ((sum > 1e-4 ? (lvl[0] + lvl[1] + lvl[2]) / 3 : 0) - loud) * Math.min(dt * 2, 1);
    return sum > 1e-4;
  }
  function glow(x, y, r, col, a) {                // col: [r, g, b] 0..255
    const g = gctx.createRadialGradient(x, y, 0, x, y, r), c = col.join(",");
    g.addColorStop(0, `rgba(${c},${a})`);
    g.addColorStop(0.5, `rgba(${c},${a * 0.35})`);
    g.addColorStop(1, `rgba(${c},0)`);
    gctx.fillStyle = g;
    gctx.fillRect(0, 0, 192, 108);
  }
  function hsl(h, s, l) {                         // -> [r, g, b] 0..255
    h = ((h % 360) + 360) % 360 / 360;
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = (t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 0.5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    return [f(h + 1 / 3), f(h), f(h - 1 / 3)].map((v) => Math.round(v * 255));
  }
  const mixc = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
  const rgb255 = (b, i) => [b[i] * 255, b[i + 1] * 255, b[i + 2] * 255].map(Math.round);

  // LOF-1: soft glows shifting with the music
  function paintLof(s) {
    const calm = still.matches ? 0 : 1, lean = (bright - 0.5) * 50;
    gctx.globalCompositeOperation = "lighter";
    glow(70 + calm * 16 * Math.sin(s * 0.07), 78 + calm * 8 * Math.sin(s * 0.05 + 1), 80 + 18 * lvl[0], hsl(hue0 - 25 + lean, 0.7, 0.55), 0.06 + 0.22 * lvl[0]);
    glow(110 + calm * 22 * Math.sin(s * 0.06 + 2), 42 + calm * 12 * Math.sin(s * 0.08), 70 + 14 * lvl[1], hsl(hue0 + lean, 0.7, 0.55), 0.05 + 0.2 * lvl[1]);
    glow(150 + calm * 18 * Math.sin(s * 0.09 + 4), 30 + calm * 10 * Math.sin(s * 0.07 + 3), 52 + 12 * lvl[2], hsl(hue0 + 40 + lean, 0.7, 0.55), 0.04 + 0.16 * lvl[2]);
  }

  // HYP-1: EQ bars and a scrolling heatmap, in the screen theme's colours
  const heat = document.createElement("canvas");
  heat.width = 320;
  heat.height = 120;
  const hctx = heat.getContext("2d");
  function paintHyp(look) {
    const pad = look ? rgb255(look, 0) : [164, 76, 255], hot = look ? rgb255(look, 3) : [255, 128, 32];
    const mid = look ? rgb255(look, 9) : [214, 128, 255], base = look ? rgb255(look, 6) : [22, 21, 27];
    const ramp = (v) => v < 0.5 ? mixc(base, pad, v * 2) : v < 0.8 ? mixc(pad, mid, (v - 0.5) / 0.3) : mixc(mid, hot, (v - 0.8) / 0.2);
    if (!still.matches) hctx.drawImage(heat, -1, 0);   // the heatmap: one column a frame, the newest at the right
    for (let k = 0; k < NB; k++) {
      const y0 = 120 - Math.round((k + 1) * 120 / NB), h = Math.round((k + 1) * 120 / NB) - Math.round(k * 120 / NB);
      hctx.fillStyle = `rgb(${ramp(eq[k]).join(",")})`;
      hctx.fillRect(319, y0, 1, h);
    }
    pctx.globalAlpha = 0.22;
    pctx.drawImage(heat, 0, 0);
    pctx.globalAlpha = 1;
    const bw = 8, segH = 3, maxSeg = 20;          // the bars: LED segments, bottom up
    for (let k = 0; k < NB; k++) {
      const x = k * bw + 1, n = Math.round(eq[k] * maxSeg), pk = Math.round(eqPeak[k] * maxSeg);
      for (let j = 0; j < n; j++) {
        const v = j / maxSeg;
        pctx.fillStyle = `rgba(${ramp(0.35 + v * 0.65).join(",")},${0.2 + 0.2 * v})`;
        pctx.fillRect(x, 178 - (j + 1) * (segH + 1), bw - 2, segH);
      }
      if (pk > 0) {
        pctx.fillStyle = `rgba(${hot.join(",")},0.45)`;
        pctx.fillRect(x, 178 - pk * (segH + 1) - 2, bw - 2, 1);
      }
    }
  }

  // ECO-1: the sky of the emulator's day; grass after a minute untouched; fireflies at night
  const FLIES = Array.from({ length: 26 }, (_, i) => ({ x: Math.random() * 320, y: 120 + Math.random() * 50, ph: Math.random() * 6.28,
    sp: 0.4 + Math.random() * 0.8, dx: Math.random() * 6.28 }));
  const BLADES = Array.from({ length: 160 }, (_, i) => ({ x: i * 2 + (Math.random() * 2 | 0), h: 6 + Math.random() * 16,
    ph: Math.random() * 6.28, c: Math.random() }));
  let idleFade = 0;
  function skyCol(day, top, rain) {               // as the firmware's sky_colour
    const sn = Math.sin((day - 0.25) * 6.2832), d = Math.min(Math.max((sn + 0.12) * 1.6, 0), 1);
    const tw = Math.min(Math.max(1 - Math.abs(sn) * 5, 0), 1);
    let c = top ? mixc([10, 14, 34], [72, 132, 196], d) : mixc([26, 32, 60], [170, 206, 226], d);
    c = top ? mixc(c, [110, 80, 120], tw * 0.4) : mixc(c, [236, 142, 92], tw * 0.75);
    return mixc(c, top ? [70, 76, 86] : [120, 126, 134], rain * 0.7 * d + rain * 0.25);
  }
  function paintEco(look, s, dt, now) {
    const day = look ? look[0] : 0.3, sun = look ? look[1] : 1, rain = look ? look[2] : 0, wind = look ? look[3] : 0.2;
    const top = skyCol(day, 1, rain), hor = skyCol(day, 0, rain);
    const g = gctx.createLinearGradient(0, 0, 0, 108);    // the sky, dimmed: the stage stays the stage
    g.addColorStop(0, `rgba(${top.join(",")},0.42)`);
    g.addColorStop(0.75, `rgba(${hor.join(",")},0.36)`);
    g.addColorStop(1, `rgba(${mixc(hor, [20, 30, 18], 0.6).join(",")},0.5)`);
    gctx.fillStyle = g;
    gctx.fillRect(0, 0, 192, 108);
    const idle = (now - lastMove) / 1000 > 60;    // a minute untouched: the grass grows in (a touch: it goes)
    idleFade = Math.min(Math.max(idleFade + (idle ? dt / 10 : -dt / 1.5), 0), 1);
    if (idleFade <= 0) return;
    const calm = still.matches ? 0 : 1, lit = 0.25 + 0.75 * sun, ga = idleFade * 0.75;
    for (const b of BLADES) {                     // grass, waving in the emulator's wind
      const sway = calm * (0.6 + 3.2 * wind) * Math.sin(s * (0.9 + 2.2 * wind) + b.ph + b.x * 0.04);
      const col = mixc([28, 60, 24], [84, 150, 62], b.c * 0.8);
      pctx.fillStyle = `rgba(${col.map((v) => Math.round(v * lit)).join(",")},${ga})`;
      const h = Math.round(b.h);
      for (let j = 0; j < h; j++) pctx.fillRect(Math.round(b.x + sway * (j / h) * (j / h)), 179 - j, 1, 1);
    }
    const night = Math.min(Math.max((0.25 - sun) / 0.2, 0), 1) * idleFade;
    if (night <= 0) return;
    for (const f of FLIES) {                      // fireflies: drifting low, glowing on and off
      if (calm) {
        f.dx += dt * 0.3 * f.sp;
        f.x = (f.x + Math.cos(f.dx) * dt * 6 * f.sp + 320) % 320;
        f.y = Math.min(Math.max(f.y + Math.sin(f.dx * 1.3) * dt * 4, 110), 172);
      }
      const on = Math.max(0, Math.sin(s * f.sp * 1.4 + f.ph)) ** 3 * night;
      if (on < 0.02) continue;
      const x = Math.round(f.x), y = Math.round(f.y);
      pctx.fillStyle = `rgba(214,255,120,${on})`;
      pctx.fillRect(x, y, 1, 1);
      pctx.fillStyle = `rgba(180,240,90,${on * 0.35})`;
      pctx.fillRect(x - 1, y, 1, 1); pctx.fillRect(x + 1, y, 1, 1); pctx.fillRect(x, y - 1, 1, 1); pctx.fillRect(x, y + 1, 1, 1);
      gctx.globalCompositeOperation = "lighter";
      glow(x * 0.6, y * 0.6, 7, [190, 250, 100], on * 0.25);
      gctx.globalCompositeOperation = "source-over";
    }
  }

  // GRAV-1: the star's colour from the centre, vignetting to black; pixel stars drifting across
  const STARS = Array.from({ length: 150 }, () => ({ x: Math.random() * 320, y: Math.random() * 180, z: Math.random(),
    ph: Math.random() * 6.28, c: Math.random() }));
  let starSize = 0.5;
  function paintGrav(look, s, dt) {
    const col = look ? rgb255(look, 0) : [255, 213, 106], sz = look ? look[3] : 0.6, flare = look ? look[4] : 0;
    starSize += (sz - starSize) * Math.min(dt * 2, 1);
    const r = 46 + 22 * starSize + 10 * loud + 12 * flare;
    gctx.globalCompositeOperation = "lighter";
    glow(96, 54, r, col, 0.22 + 0.12 * loud + 0.15 * flare);
    glow(96, 54, r * 0.45, mixc(col, [255, 255, 255], 0.3), 0.1 + 0.08 * starSize);
    const calm = still.matches ? 0 : 1;
    for (const st of STARS) {                     // three depths, the far ones slow and dim
      if (calm) st.x -= dt * (1.2 + st.z * 5);
      if (st.x < 0) { st.x += 320; st.y = Math.random() * 180; }
      const tw = 0.55 + 0.45 * Math.sin(s * (0.6 + st.z) + st.ph), a = (0.15 + 0.55 * st.z) * tw;
      const c = st.c < 0.7 ? [230, 235, 255] : st.c < 0.85 ? mixc(col, [255, 255, 255], 0.4) : [170, 190, 255];
      pctx.fillStyle = `rgba(${c.join(",")},${a})`;
      pctx.fillRect(Math.round(st.x), Math.round(st.y), 1, 1);
      if (st.z > 0.92) { pctx.fillStyle = `rgba(${c.join(",")},${a * 0.3})`; pctx.fillRect(Math.round(st.x) - 1, Math.round(st.y), 3, 1); }
    }
  }

  // CTY-1: the sky over the city; a pixel skyline, taller as it grows, lit at night; sirens; lightning
  const TOWERS = (() => { const a = []; let x = 0, r = 7; const rnd = () => ((r = (r * 1103515245 + 12345) >>> 0) >>> 8) / 16777216;
    while (x < 320) { const w = 6 + (rnd() * 12 | 0); a.push({ x, w, h: rnd(), k: rnd() }); x += w + (rnd() * 3 | 0); } return a; })();
  let cityH = 0;
  function paintCty(look, s, dt) {
    const sky = look ? rgb255(look, 0) : [110, 170, 230], day = look ? look[3] : 1, flash = look ? look[4] : 0;
    const siren = look ? look[5] : 0, stage = look ? look[7] : 0, biome = look ? look[8] : 0, dis = look ? look[9] : 0;
    const g = gctx.createLinearGradient(0, 0, 0, 108);
    g.addColorStop(0, `rgba(${sky.join(",")},0.40)`);
    g.addColorStop(1, `rgba(${mixc(sky, [255, 200, 140], 0.25 * (1 - Math.abs(day - 0.5) * 2)).join(",")},0.30)`);
    gctx.fillStyle = g;
    gctx.fillRect(0, 0, 192, 108);
    cityH += ((0.25 + stage * 0.25) - cityH) * Math.min(dt * 0.5, 1);
    const night = Math.min(Math.max((0.5 - day) / 0.35, 0), 1), base = mixc([40, 44, 56], [14, 16, 26], night);
    const land = mixc([[52, 70, 54], [150, 92, 60], [96, 104, 116], [60, 56, 56], [120, 112, 70], [70, 120, 150], [56, 90, 80]][biome | 0] || [52, 70, 54],
                      [14, 16, 24], night * 0.8);
    for (let x = 0; x < 320; x += 2) {          // the land behind the city, the biome's
      let h = 0;
      if (biome === 2) h = 70 + 45 * Math.abs(Math.sin(x * 0.021)) + 18 * Math.sin(x * 0.07);      // mountains
      else if (biome === 1) h = (Math.sin(x * 0.03) > 0.3 ? 52 : 18) + 4 * Math.sin(x * 0.2);      // mesas
      else if (biome === 3) h = Math.max(0, 95 - Math.abs(x - 230) * 1.1) + 10;                    // the volcano
      else if (biome === 5 || biome === 6) h = 8;                                                 // the sea, the river
      else h = 22 + 10 * Math.sin(x * 0.04) + 6 * Math.sin(x * 0.11);                               // hills
      pctx.fillStyle = `rgba(${land.join(",")},0.55)`;
      pctx.fillRect(x, 180 - h, 2, h);
      if (biome === 2 && h > 98) { pctx.fillStyle = `rgba(${mixc([240, 244, 248], [90, 96, 110], night).join(",")},0.6)`; pctx.fillRect(x, 180 - h, 2, h - 98); }
    }
    if (biome === 3) {                            // the volcano: smoke, and its glow (an eruption: red)
      const e = dis === 4, g = gctx;
      g.globalCompositeOperation = "lighter";
      glow(138, 46, e ? 26 : 10, e ? [255, 90, 30] : [255, 140, 60], e ? 0.35 : 0.12);
      g.globalCompositeOperation = "source-over";
      for (let k = 0; k < 5; k++) { const ph = ((s * 0.12 + k / 5) % 1); pctx.fillStyle = `rgba(${e ? "70,60,56" : "200,196,190"},${0.35 * (1 - ph)})`;
        pctx.fillRect(228 + ph * 30, 80 - ph * 70, 6 + ph * 14, 5 + ph * 10); }
    }
    for (const t of TOWERS) {                     // the skyline: the tall ones only as the city gets big
      const h = Math.round(8 + t.h * t.h * 70 * cityH + loud * 3);
      pctx.fillStyle = `rgba(${base.join(",")},0.85)`;
      pctx.fillRect(t.x, 180 - h, t.w, h);
      if (night > 0.05)
        for (let y = 180 - h + 3; y < 177; y += 4)
          for (let x = t.x + 2; x < t.x + t.w - 2; x += 3) {
            const lit = Math.sin(x * 12.9898 + y * 78.233 + Math.floor(s / 20) * 3.1) * 43758.5;
            if (lit - Math.floor(lit) < 0.35 + 0.2 * t.k) { pctx.fillStyle = `rgba(255,205,105,${0.75 * night})`; pctx.fillRect(x, y, 1, 1); }
          }
    }
    gctx.globalCompositeOperation = "lighter";
    if (siren) {                                  // red and blue (police), red and white (fire, ambulance)
      const ph = Math.sin(s * 9) > 0, c = siren === 2 ? (ph ? [255, 60, 50] : [80, 160, 255]) : (ph ? [255, 60, 50] : [255, 240, 230]);
      glow(ph ? 40 : 152, 100, 40, c, 0.18);
    }
    if (flash > 0) { gctx.fillStyle = `rgba(235,240,255,${0.35 * flash})`; gctx.fillRect(0, 0, 192, 108); }
  }

  function drawBg(t) {
    if (t - lastBg < 33) return;                  // 30 a second
    const dt = Math.min((t - lastBg) / 1000, 0.1), s = t / 1000;
    lastBg = t;
    listen();
    if (an) hear(dt);
    const look = window.ambLast && window.ambLast.bg;
    gctx.globalCompositeOperation = "source-over";
    gctx.clearRect(0, 0, 192, 108);
    pctx.clearRect(0, 0, 320, 180);
    if (name === "HYP-1") paintHyp(look);
    else if (name === "ECO-1") paintEco(look, s, dt, t);
    else if (name === "GRAV-1") paintGrav(look, s, dt);
    else if (name === "CTY-1") paintCty(look, s, dt);
    else paintLof(s);
    gctx.globalCompositeOperation = "source-over";
  }
  (function tick(t) {                             // the screen, large; the remote's badge; the background
    if (on) {
      bctx.drawImage(screen, 0, 0);
      stage.classList.toggle("linked", dev.classList.contains("remote"));
      drawBg(t || 0);
    }
    requestAnimationFrame(tick);
  })();
  // the last few moves, under the screen
  function say(s, same) {
    lastMove = performance.now();               // a move: ECO-1's grass goes, and comes back a minute later
    const last = moves.lastElementChild;
    if (same && last && last.dataset.k === same && Date.now() - last.dataset.t < 900) {
      last.dataset.n = +last.dataset.n + 1;
      last.textContent = s + (last.dataset.n > 1 ? " ×" + last.dataset.n : "");
      last.dataset.t = Date.now();
      return;
    }
    const e = document.createElement("span");
    e.textContent = s;
    e.dataset.k = same || "";
    e.dataset.n = 1;
    e.dataset.t = Date.now();
    moves.appendChild(e);
    while (moves.children.length > 7) moves.firstElementChild.remove();
  }
  setInterval(() => { for (const e of moves.children) e.classList.toggle("old", Date.now() - e.dataset.t > 3000); }, 400);
  const BTN_NAME = {};
  for (const [n, b] of Object.entries(buttons)) BTN_NAME[b.bit] = n;
  let seenB = 0, seenK = 0;
  const _sb = syncButtons, _sk = syncKeys, _turn = turn;
  syncButtons = function () {                     // what goes down, named; held ones glow (the page's .held)
    _sb.apply(this, arguments);
    let m = 0;
    for (const b of btnHeldBy.values()) m |= 1 << b;
    const down = m & ~seenB;
    seenB = m;
    if (down) {
      const ns = Object.keys(BTN_NAME).filter((b) => down & (1 << b)).map((b) => BTN_NAME[b]);
      const held = Object.keys(BTN_NAME).filter((b) => (m & ~down) & (1 << b)).map((b) => BTN_NAME[b]);
      say((held.length ? held.join(" + ") + " + " : "") + ns.join(" + "));
    }
  };
  syncKeys = function () {
    _sk.apply(this, arguments);
    let m = 0;
    for (const k of keyHeldBy.values()) m |= 1 << k;
    const down = m & ~seenK;
    seenK = m;
    for (let i = 0; i < 27; i++) if (down & (1 << i)) { const n = 53 + i; say("KEY " + NOTE[n % 12] + (Math.floor(n / 12) - 1)); }
  };
  turn = function (k, n) {                        // a knob turning: a ring for a moment, and its name
    _turn.apply(this, arguments);
    if (!n) return;
    const label = Object.keys(knobs).find((x) => knobs[x] === k) || "KNOB";
    k.g.classList.add("sv-turn");
    clearTimeout(k.svT);
    k.svT = setTimeout(() => k.g.classList.remove("sv-turn"), 700);
    say(label.replace(/^KNOB(\d)/, "KNOB $1") + (n > 0 ? " ▲" : " ▼"), label + (n > 0 ? "+" : "-"));
  };
  stage.querySelector('[data-a="exit"]').addEventListener("click", () => set(false));
  stage.querySelector('[data-a="midi"]').addEventListener("click", () => {
    const b = document.getElementById("midi-go") || document.getElementById("midiOn");
    if (b) b.click();
  });
  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Stream view";
  btn.title = "For livestreams: the FM-1 and its screen large on a 16:9 stage (or open this page with ?stream)";
  const bar = document.querySelector(".bar");
  if (bar) bar.appendChild(btn);
  btn.addEventListener("click", () => set(true));
  if (new URLSearchParams(location.search).has("stream")) set(true);
})();
""" + JB


def put(text, block, a, b, before):
    if a in text:
        i, j = text.index(a), text.index(b) + len(b)
        return text[:i] + block + text[j:]
    k = text.rindex(before)
    return text[:k] + block + "\n" + text[k:]


def main():
    for p in PAGES:
        s = p.read_text()
        while A in s:                            # the first version's block, one marker for both
            i, j = s.index(A), s.index(B) + len(B)
            s = s[:i] + s[j:].lstrip("\n")
        s = put(s, CSS, CA, CB, "</style>")
        s = put(s, JS, JA, JB, "</script>")
        p.write_text(s)
        print("stream view:", p.relative_to(SRC))


if __name__ == "__main__":
    main()
